# Worksuite + Filament Mapping

## Worksuite should own
- invoice truth
- accounting truth
- payment posting
- company/customer/booking tenancy
- core notifications backbone
- package/permission/menu registration

## ZeroPay module should own
- payment session object
- QR + pay-link generation
- rail selection page
- surcharge display logic
- download token flow
- follow-up orchestration
- reconciliation assist queue
- AI/voice controls

## Filament pages/resources to build
- Payment Sessions Resource
- Payment Attempts Resource
- Bank Match Queue
- Cash Reconciliation Queue
- Gateway Settings Page
- PayID / Bank Details Page
- Follow-up AI Settings
- Voice Automation Settings
- ZeroPay Analytics Dashboard
