# QRPay Strip Strategy for Worksuite Merge

This pack strips QRPay v5.1 down to the parts most useful for a Worksuite/Filament merge.

## Kept on purpose
- merchant controllers
- merchant API controllers
- QRPay payment-gateway controllers
- payment link, transaction, wallet, merchant, QR, gateway setting models
- payment and merchant migrations
- merchant and paylink views
- payment gateway traits
- payment notifications
- providers, helpers, constants relevant to payments
- selected mobile app payment and wallet flows

## Excluded on purpose
- agent subsystem
- remittance flows
- mobile topup
- bill pay
- gift cards
- blogs / marketing pages
- KYC and support ticket bulk
- virtual card subsystems
- consumer-wallet-only surfaces not useful for ZeroPay MVP

## Merge goal
Build ZeroPay as a Worksuite payment operations module rather than importing QRPay wholesale.
