# Strip Inventory

## QRPay Web Stripped
- Files: 310
- Controllers: 38
- Models: 35
- Migrations: 45
- Routes: 6
- Views: 82
- Traits: 21
- Notifications: 65
- Providers: 9
- Helpers + Constants: 9

## QRPay User App Stripped
- Files: 430
- Dart files: 343
- Lib files: 343
- Assets: 75
