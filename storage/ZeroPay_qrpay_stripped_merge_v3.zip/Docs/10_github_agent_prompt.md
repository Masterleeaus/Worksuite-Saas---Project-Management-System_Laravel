# GitHub Agent Prompt

Deep-scan this pack and build ZeroPay as a Worksuite module with Filament admin surfaces.

Rules:
- use `Codebase/00_TitanPay_Base` as the base
- selectively port from `Codebase/01_QRPay_Web_Stripped`
- selectively borrow mobile UX from `Codebase/02_QRPay_UserApp_Stripped`
- do not import QRPay wholesale
- keep company_id tenant boundaries
- preserve Worksuite invoice/payment/accounting truth
- expose named routes and API routes
- produce Filament resources/pages for operations and settings
- keep zero-fee rails first and paid rails optional
- implement AI follow-up settings and voice settings as module surfaces
