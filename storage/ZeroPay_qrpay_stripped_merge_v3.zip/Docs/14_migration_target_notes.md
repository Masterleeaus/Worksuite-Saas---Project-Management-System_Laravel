# Migration Target Notes

## Keep from QRPay as reference
- transaction / charge separation
- wallet and ledger patterns only where useful
- gateway settings tables
- merchant receive-money structures

## Rewrite for Worksuite
- standalone user/account assumptions
- QRPay auth-linked ownership tables
- broad wallet ecosystem tables
- consumer remittance flows

## ZeroPay-first schema rule
Favor a small clean schema that maps into Worksuite accounting rather than importing large QRPay migration sets wholesale.
