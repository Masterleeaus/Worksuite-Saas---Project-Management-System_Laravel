# Voice Tier Architecture

Highest tier should include:
- AI voice-controlled operator interface
- outbound reminder call flows
- Twilio integration
- ElevenLabs or Google voice stack
- configurable call escalation policy
- optional transfer to human

## Suggested controls
- enable voice followup
- max attempts
- call windows
- overdue thresholds
- do-not-call rules
- human handoff targets
