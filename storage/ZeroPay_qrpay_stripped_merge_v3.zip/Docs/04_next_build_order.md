# Next Build Order

1. Use TitanPay as the base module
2. Add ZeroPay session-first schema
3. Port merchant payment link + receive-money flow from stripped QRPay web
4. Port selected payment gateway traits and checkout handlers
5. Rebuild admin/operator UI in Filament
6. Wire invoice posting into Worksuite payments/accounting
7. Port selected mobile payment and QR flows into Titan Go or customer payment app surfaces
8. Add AI follow-up and voice-control layers after session engine is stable
