# Filament Resource Plan

## Resources
- PaymentSessionResource
- PaymentAttemptResource
- BankMatchResource
- FollowupQueueResource
- ChannelLogResource

## Pages
- ZeroPaySettingsPage
- ZeroPayGatewaySettingsPage
- ZeroPayVoiceSettingsPage
- ZeroPayAnalyticsPage
- ZeroPayDashboardPage

## Widgets
- SessionsSentToday
- SessionsPaidToday
- AwaitingConfirmationCount
- BankMatchQueueCount
- OverdueFollowupCount
- ZeroFeeVsPaidRailChart
