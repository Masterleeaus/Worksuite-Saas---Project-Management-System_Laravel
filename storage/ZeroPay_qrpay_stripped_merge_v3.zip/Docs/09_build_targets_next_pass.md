# Build Targets for the Next Code Pass

## Target 1
Create `Modules/ZeroPay/` using TitanPay as the base.

## Target 2
Port these feature families from stripped QRPay:
- payment-link flow
- receive-money QR flow
- card/PayPal gateway adapters
- transaction/charge logging patterns
- selected notifications
- selected mobile payment UX patterns

## Target 3
Implement Filament resources:
- sessions
- attempts
- bank matches
- settings
- analytics

## Target 4
Wire into Worksuite:
- Invoice
- Payment
- OfflinePaymentMethod
- PaymentGatewayCredentials
- booking deposits if available
