# Worksuite Target Map

## Core models to integrate with
- Invoice
- Payment
- InvoicePaymentDetail
- OfflinePaymentMethod
- PaymentGatewayCredentials
- Company
- User
- Client / Customer equivalent
- Booking or appointment entity where available

## ZeroPay tables to add
- zeropay_sessions
- zeropay_attempts
- zeropay_download_tokens
- zeropay_bank_matches
- zeropay_followups
- zeropay_channel_logs
- zeropay_voice_runs
- zeropay_ai_suggestions

## Posting rule
ZeroPay should not replace core Payments.
ZeroPay should create session/attempt/orchestration records, then write confirmed financial outcomes back into Worksuite payment records.
