# Next Code Pass Prompt

Deep-scan this pack and begin the real module conversion.

## Goal
Create a merge-safe `Modules/ZeroPay/` inside Worksuite using TitanPay as the base, QRPay stripped files as donor code, and Filament as the new admin surface.

## Deliverables
- real ZeroPay migrations
- real ZeroPay services
- real ZeroPay routes
- initial Filament resources/pages
- initial payment session page
- gateway settings
- PayID/bank settings
- callback stubs
- AI/voice settings stubs

## Rules
- preserve Worksuite accounting/payment truth
- preserve company_id tenant boundary
- do not import QRPay wholesale
- use QRPay stripped files selectively
- keep zero-fee rails first
