# Merge Targets

## Direct merge candidates into ZeroPay
- merchant payment link flow
- merchant receive-money QR flow
- checkout / payment gateway flow
- transaction history patterns
- merchant gateway settings
- notification patterns
- wallet and transaction model ideas for ledger support
- selected mobile payment UI and payment-status screens

## Keep in Worksuite as source of truth
- invoices
- accounting
- customers/companies
- permissions
- business settings
- notifications backbone where already present

## Use Filament for
- ZeroPay settings
- payment session dashboard
- reconciliation queue
- bank transfer matching queue
- AI follow-up controls
- voice settings
