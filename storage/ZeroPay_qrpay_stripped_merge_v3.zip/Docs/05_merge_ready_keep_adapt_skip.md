# Merge-Ready Keep / Adapt / Skip

## Keep directly
These QRPay surfaces are strong candidates to port nearly as-is into ZeroPay:
- merchant payment-link controllers
- payment gateway traits and callback logic
- merchant gateway setting controllers and views
- payment notifications
- selected transaction and charge models
- selected mobile payment screens and payment-status widgets

## Adapt heavily
These should be rewritten around Worksuite and ZeroPay concepts:
- wallet models
- merchant dashboards
- route structure
- session/payment object model
- migrations referencing standalone QRPay architecture
- user/account auth assumptions
- mobile app navigation and auth flows

## Skip for ZeroPay MVP
These should not be merged now:
- remittance ecosystems
- bill pay / topup
- gift cards
- virtual cards
- support / KYC bulk
- blog/marketing content
- broad consumer-wallet-only surfaces
