# Mobile Merge Notes

Use the stripped QRPay user app as a UX donor, not as a final app to install unchanged.

## Good candidates to borrow
- payment status screens
- QR presentation flow
- transaction list UI
- wallet/payment cards UI ideas
- merchant receive/payment screen patterns
- notification and success/failure screen patterns

## Merge target
Port the best payment UI into:
- Titan Go
- customer portal app
- dedicated customer payment screens if needed
