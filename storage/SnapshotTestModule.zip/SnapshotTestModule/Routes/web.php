<?php

use Illuminate\Support\Facades\Route;

Route::get('/snapshottestmodule', fn () => 'ok');
