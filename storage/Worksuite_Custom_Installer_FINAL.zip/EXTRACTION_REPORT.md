# Custom Module Installer Extraction

Source: `worksuite_saas_with_titan_dbdev_pass26_recreated.zip`

Included the current custom module installer controller, module settings bridge, relevant models, observers, migration, installer/module-settings views, route files, and key language/sidebar/menu references.

## Extracted files
- `app/Http/Controllers/CustomModuleController.php`
- `app/Http/Controllers/ModuleSettingController.php`
- `app/Models/CustomModulePermission.php`
- `app/Models/ModuleSetting.php`
- `app/Observers/CompanyObserver.php`
- `app/Observers/SuperAdmin/PackageObserver.php`
- `app/Console/Commands/FixUpgradeCompanyCommand.php`
- `database/migrations/2023_06_15_104818_fix_company_packages.php`
- `resources/views/custom-modules/sections/universal-bundle.blade.php`
- `resources/views/custom-modules/sections/version.blade.php`
- `resources/views/custom-modules/sections/purchase-code.blade.php`
- `resources/views/custom-modules/sections/module-update.blade.php`
- `resources/views/custom-modules/sections/support-date.blade.php`
- `resources/views/custom-modules/install.blade.php`
- `resources/views/custom-modules/ajax/custom.blade.php`
- `resources/views/custom-modules/ajax/verify.blade.php`
- `resources/views/module-settings/index.blade.php`
- `resources/views/module-settings/ajax/modules.blade.php`
- `resources/views/components/super-admin/setting-sidebar.blade.php`
- `resources/views/components/setting-sidebar.blade.php`
- `resources/views/sections/menu.blade.php`
- `routes/web-settings.php`
- `routes/SuperAdmin/web.php`
- `resources/lang/eng/app.php`
- `resources/lang/eng/permissions.php`
- `resources/lang/eng/modules.php`
- `resources/lang/eng/messages.php`
