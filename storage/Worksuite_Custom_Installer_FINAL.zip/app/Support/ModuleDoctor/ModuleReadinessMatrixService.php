<?php

namespace App\Support\ModuleDoctor;

use Illuminate\Support\Collection;

class ModuleReadinessMatrixService
{
    public function build(array $analysis): array
    {
        $checks = collect($analysis['checks'] ?? []);
        $visibility = $analysis['visibility_report'] ?? [];
        $checkIndex = $this->buildCheckIndex($checks);

        $flags = [
            'filesystem_ready' => $this->combineStatuses([
                $this->statusFromLabels($checkIndex, ['ZIP readable', 'Archive root shape', 'Extracted module folder', 'module.json manifest', 'Config/config.php']),
            ]),
            'provider_ready' => $this->combineStatuses([
                $this->statusFromLabels($checkIndex, ['Service providers', 'Parent product ID', 'Parent product name', 'Minimum Worksuite version']),
                $this->normaliseStatus(data_get($visibility, 'provider_boot.status')),
            ]),
            'routes_ready' => $this->combineStatuses([
                $this->statusFromLabels($checkIndex, ['Routes', 'Route readiness', 'Route collision check', 'Migration filename conflicts']),
                $this->normaliseStatus(data_get($visibility, 'routes.status')),
                empty(data_get($visibility, 'sidebar.route_resolution.missing_route_names', [])) ? 'pass' : 'warn',
            ]),
            'views_ready' => $this->combineStatuses([
                $this->statusFromLabels($checkIndex, ['Views or language resources', 'Sidebar readiness']),
                !empty(data_get($visibility, 'sidebar.files', [])) ? 'pass' : 'warn',
                !empty(data_get($visibility, 'sidebar.inclusion.core_sidebar_hits', [])) ? 'pass' : 'warn',
            ]),
            'db_registered' => $this->combineStatuses([
                $this->statusFromLabels($checkIndex, ['Existing module conflict']),
                $this->normaliseStatus(data_get($visibility, 'runtime_registry.status')),
            ]),
            'permissions_ready' => $this->combineStatuses([
                $this->statusFromLabels($checkIndex, ['Permission readiness', 'Permission collision check']),
                empty(data_get($visibility, 'permissions.db_audit.missing', [])) ? 'pass' : 'warn',
                !empty(data_get($visibility, 'permissions.permission_keys', [])) ? 'pass' : 'warn',
            ]),
            'package_ready' => $this->combineStatuses([
                $this->statusFromLabels($checkIndex, ['Package bridge readiness']),
                !empty(data_get($visibility, 'package_bridge.db_entitlements.packages', [])) ? 'pass' : 'warn',
            ]),
            'module_settings_ready' => $this->combineStatuses([
                !empty(data_get($visibility, 'package_bridge.company_module_settings.rows', [])) ? 'pass' : 'warn',
                $this->statusFromLabels($checkIndex, ['User menu visibility']),
            ]),
            'menu_ready' => $this->combineStatuses([
                $this->statusFromLabels($checkIndex, ['Menu readiness', 'Sidebar readiness', 'User menu visibility']),
                empty(data_get($visibility, 'menu_registration.missing', [])) ? 'pass' : 'warn',
                empty(data_get($visibility, 'sidebar.route_resolution.missing_route_names', [])) ? 'pass' : 'warn',
            ]),
            'tenant_ready' => $this->tenantStatus($visibility['tenant'] ?? []),
            'cache_ready' => $this->cacheStatus($analysis),
        ];

        $weights = [
            'filesystem_ready' => 1.0,
            'provider_ready' => 1.2,
            'routes_ready' => 1.2,
            'views_ready' => 0.8,
            'db_registered' => 1.0,
            'permissions_ready' => 1.1,
            'package_ready' => 1.0,
            'module_settings_ready' => 1.2,
            'menu_ready' => 1.2,
            'tenant_ready' => 1.2,
            'cache_ready' => 0.5,
        ];
        $statusScore = ['pass' => 1.0, 'warn' => 0.5, 'fail' => 0.0];
        $weightedScore = 0.0;
        $weightTotal = 0.0;
        foreach ($flags as $key => $status) {
            $weight = $weights[$key] ?? 1.0;
            $weightedScore += ($statusScore[$status] ?? 0.0) * $weight;
            $weightTotal += $weight;
        }
        $score = (int) round(($weightedScore / max($weightTotal, 1.0)) * 100);

        $blocking = array_keys(array_filter($flags, fn ($status) => $status === 'fail'));
        $warnings = array_keys(array_filter($flags, fn ($status) => $status === 'warn'));

        return [
            'flags' => $flags,
            'score' => $score,
            'status' => $score >= 90 ? 'pass' : ($score >= 65 ? 'warn' : 'fail'),
            'blocking_flags' => $blocking,
            'warning_flags' => $warnings,
            'summary' => $this->buildSummary($flags, $score),
            'next_focus' => $blocking[0] ?? ($warnings[0] ?? null),
            'audience' => [
                'user_surface' => $this->combineStatuses([$flags['menu_ready'], $flags['module_settings_ready'], $flags['tenant_ready']]),
                'admin_surface' => $this->combineStatuses([$flags['provider_ready'], $flags['routes_ready'], $flags['db_registered']]),
            ],
        ];
    }

    protected function buildCheckIndex(Collection $checks): array
    {
        $index = [];
        foreach ($checks as $check) {
            $label = (string) ($check['label'] ?? '');
            if ($label === '') {
                continue;
            }
            $index[$label][] = $this->normaliseStatus($check['status'] ?? null);
        }
        return $index;
    }

    protected function statusFromLabels(array $checkIndex, array $labels): string
    {
        $statuses = [];
        foreach ($labels as $label) {
            foreach (($checkIndex[$label] ?? []) as $status) {
                $statuses[] = $status;
            }
        }
        return $this->combineStatuses($statuses);
    }

    protected function combineStatuses(array $statuses): string
    {
        $statuses = array_values(array_filter(array_map(fn ($status) => $this->normaliseStatus($status), $statuses)));
        if (empty($statuses)) {
            return 'warn';
        }
        if (in_array('fail', $statuses, true)) {
            return 'fail';
        }
        if (in_array('warn', $statuses, true)) {
            return 'warn';
        }

        return 'pass';
    }

    protected function normaliseStatus($status): string
    {
        $status = strtolower((string) $status);
        return in_array($status, ['pass', 'warn', 'fail'], true) ? $status : 'warn';
    }

    protected function tenantStatus(array $tenant): string
    {
        if (empty($tenant)) {
            return 'warn';
        }
        foreach ($tenant as $profile) {
            if (($profile['status'] ?? '') === 'fail') {
                return 'fail';
            }
        }
        foreach ($tenant as $profile) {
            if (($profile['status'] ?? '') !== 'pass') {
                return 'warn';
            }
        }

        return 'pass';
    }

    protected function cacheStatus(array $analysis): string
    {
        if (!empty($analysis['auto_repairs']) && collect($analysis['auto_repairs'])->contains(fn ($repair) => str_contains(strtolower((string) ($repair['title'] ?? '')), 'cache'))) {
            return 'pass';
        }
        if (($analysis['installability_status'] ?? '') === 'ready') {
            return 'pass';
        }

        return 'warn';
    }

    protected function buildSummary(array $flags, int $score): string
    {
        $failed = array_keys(array_filter($flags, fn ($status) => $status === 'fail'));
        $warn = array_keys(array_filter($flags, fn ($status) => $status === 'warn'));

        if ($score >= 90) {
            return 'Readiness is strong across registry, routes, permissions, package, tenant, and menu surfaces.';
        }
        if (!empty($failed)) {
            return 'Blocking readiness gaps: ' . implode(', ', $failed) . '.';
        }
        if (!empty($warn)) {
            return 'Warnings remain in: ' . implode(', ', $warn) . '.';
        }

        return 'Readiness requires review.';
    }
}
