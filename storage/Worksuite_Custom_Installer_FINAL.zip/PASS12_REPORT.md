# Pass 12 — Permission + Package Truth Upgrade

This pass extends the module installer from static route/sidebar heuristics into database-backed Worksuite visibility truth.

## Added
- module_menu_blockers model + migration
- DB schema truth snapshot
- role catalog + permission pivot matrix
- extension registry truth audit
- module_settings truth + company_module_settings truth
- live menu registration audit
- route-name mismatch explainer
- tenant visibility proof layer
- menu risk scoring + install guard rails
- export-ready visibility payload

## Goal
Catch the exact Worksuite failure mode where a module is installed, visible in packages, and enabled, but still blocked from the tenant user menu.
