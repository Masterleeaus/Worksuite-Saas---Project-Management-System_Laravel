Pass 85

- Added missing `app/Helper/Files.php` from Worksuite site.
- Replaced broad route bundles with installer-only Worksuite route slices.
- Fixed route drift by adding `custom-modules.apply_safe_fixes` and keeping `custom-modules.safe-fix` as preview/compat path.
- Removed unrelated observer/upgrade/bootstrap files that were inflating host dependencies without serving the installer overlay.
- Added manifest profile notes from real `modules.zip` scans.
