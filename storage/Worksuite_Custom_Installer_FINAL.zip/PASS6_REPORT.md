Pass 6 real changes
- Added real post-install runtime actions: enable module, run module:migrate, doctor audit.
- Added installed-module health audit with path/discovery/enabled/package/module_settings checks.
- Added new installer UI toggles for enable, migrate, and doctor audit.
- Expanded post-install diagnostics to render nested audit details.
