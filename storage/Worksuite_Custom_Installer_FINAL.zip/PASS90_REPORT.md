Upgraded custom modules installer pass.

Included fixes:
- strict post-install validation with rollback on discovery/enable/registry failure
- automatic modules table catalog sync on install and audit
- default auto-enable, migration, permission seed, and module_settings seeding during install
- new migration to enhance modules table for module registry/doctor state
