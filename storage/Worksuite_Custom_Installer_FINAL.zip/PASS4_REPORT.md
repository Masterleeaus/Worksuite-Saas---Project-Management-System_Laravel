# Pass 4 real changes

This pass makes the installer diagnostics more actionable.

## Actual code changes
- Added **menu readiness** analysis to `CustomModuleController`
- Added **permission readiness** analysis to `CustomModuleController`
- Added **package bridge readiness** analysis to `CustomModuleController`
- Added **next-step checklist** rendering to diagnostics HTML

## What the analyzer now explains
- whether the ZIP has obvious menu/sidebar wiring
- whether permission seeders or permission hints exist
- whether the package appears to contain company/package bridge logic
- exact next actions after analyze/install fails
