PASS 8
- Darkened warning and blocking diagnostics panels for better contrast on dark themes.
- Added auto-repair toggle for missing Worksuite parent metadata during analyze/install.
- Missing parent_envato_id / parent_product_name / parent_min_version are now inferred for Worksuite base and treated as repairable warnings instead of hard blockers.
- Installer now permits upgrade-candidate installs and snapshots the installed module before replacement.
- Config/config.php is patched only inside the staged module copy before install when inferred Worksuite metadata is missing.
- Preserved protected paths: resources/views/sections/menu.blade.php and app/Console/Commands/* are untouched.
