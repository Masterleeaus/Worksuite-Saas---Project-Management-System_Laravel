Pass 5 real changes
- Added install options UI for package attachment, company module_settings seeding, and permission seeder execution.
- Added package list loading from the packages table in installer create().
- Added real post-install actions in CustomModuleController:
  - attach module slug into packages.module_in_package for all or selected packages
  - seed module_settings rows for admin/employee/client across matching companies
  - optionally run module:seed
- Added post-install action results into diagnostics HTML.
