# Remaining Host Dependencies After Pass 85

Counts:
- controllers: 0
- models: 14
- traits: 1
- scopes: 1
- helpers: 0
- other: 1

## Traits
- `App\Traits\HasMaskImage`

## Scopes
- `App\Scopes\SuperAdminModuleScope as ScopesSuperAdminModuleScope`

## Models
- `App\Models\Company`
- `App\Models\FileStorage`
- `App\Models\ProjectActivity`
- `App\Models\ProjectTimeLog`
- `App\Models\StorageSetting`
- `App\Models\SuperAdmin\GlobalCurrency`
- `App\Models\SuperAdmin\OfflinePlanChange`
- `App\Models\SuperAdmin\SupportTicket`
- `App\Models\TaskHistory`
- `App\Models\UniversalSearch`
- `App\Models\User`
- `App\Models\UserActivity`
- `App\Models\UserAuth`
- `App\Models\UserChat`

## Other
- `App\Services\CustomModules\Actions\{
    QueuePermissionRepairAction,
    QueuePackageBridgeRepairAction,
    QueueCompanyModuleSettingsRepairAction,
    QueueCacheClearAction,
}`
