
# Pass 7 - Worksuite-only upgrade start

## Goals
- keep Worksuite as the only target profile
- preserve custom menu blade and existing app console commands
- improve installer diagnostics into a repair-plan workflow
- add backup snapshot support before module replacement
- fix packages schema drift (`package` vs `package_name`)

## Changes
- `CustomModuleController.php`
  - dynamic package column detection
  - package choice labels normalized
  - backup snapshot hook before upgrade replace
  - repair plan and risk profile now included in analysis output
- `resources/views/custom-modules/install.blade.php`
  - repair level selector
  - backup snapshot toggle
  - package label rendering uses dynamic schema-safe field
- `app/Support/ModuleDoctor/InstallSnapshotService.php`
- `app/Support/ModuleDoctor/RepairPlanService.php`

## Protected paths
- `resources/views/sections/menu.blade.php` intentionally excluded
- `app/Console/Commands/*` intentionally excluded from this rebuild
