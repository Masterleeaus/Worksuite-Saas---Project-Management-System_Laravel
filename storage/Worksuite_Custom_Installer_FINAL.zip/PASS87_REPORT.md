PASS 87

- Fixed a real readiness bug in `PackageBridgeReadinessService`: it now resolves a string module name before calling registry/package/company audits.
- Added explicit `ready` flags to package/company/runtime registry audit responses so downstream checks stop guessing.
- Tightened extracted module path resolution to prefer manifest-matched nested module roots instead of the first folder found.
- Aligned `validateModule()` with real `modules.zip` patterns: case-insensitive manifest name matching and `files: null` acceptance.
- Cleaned lingering UI wording from `extension registry` to `runtime/module registry`.
- Refreshed the modules-scan manifest profile doc from the latest `modules.zip`.
