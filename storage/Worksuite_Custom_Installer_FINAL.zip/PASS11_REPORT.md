# Pass 11 Report

## Highlights
- Added registered-route audit for sidebar and route file references
- Added sidebar inclusion audit against common Worksuite sidebar entry points
- Added permission DB audit and company permission scope checks
- Added package entitlement and module_settings audits
- Added richer tenant visibility explanations and checklist output
- Preserved protected paths: `resources/views/sections/menu.blade.php`, `app/Console/Commands/*`
