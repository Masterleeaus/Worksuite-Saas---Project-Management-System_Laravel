# Custom Installer Scan and Merge

## Source archive
- customextensions .zip

## Selected merge order
- worksuite_base: customextensions /worksuite/custom_module.zip (added 182, replaced 0)
- worksuite_upgrade: customextensions /worksuite/custom_module_installer_upgrade_pass10_visibility_hardening.zip (added 0, replaced 70)
- magicai_unified: customextensions /Custom Extension Installer /magicai_custom_installer_unified_system_pass79_routes_titandocs.zip (added 209, replaced 143)

## Included roots
- EXTRACTION_REPORT.json
- EXTRACTION_REPORT.md
- PASS11_REPORT.md
- PASS12_REPORT.md
- PASS16_REPORT.md
- PASS4_REPORT.md
- PASS5_REPORT.md
- PASS6_REPORT.md
- PASS7_REPORT.md
- PASS8_REPORT.md
- PASS9_REPORT.md
- TitanDocs
- app
- config
- database
- packages
- public
- resources
- routes
- tests