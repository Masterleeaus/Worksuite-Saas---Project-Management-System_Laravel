<?php

namespace Modules\OpsWizardBuilders\Providers;

use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Route;

class RouteServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        parent::boot();

        Route::middleware('web')->group(module_path('OpsWizardBuilders', '/Routes/web.php'));
    }
}
