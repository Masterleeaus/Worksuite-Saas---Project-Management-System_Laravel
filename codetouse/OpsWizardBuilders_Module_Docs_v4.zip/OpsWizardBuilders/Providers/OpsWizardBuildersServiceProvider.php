<?php

namespace Modules\OpsWizardBuilders\Providers;

use Illuminate\Support\Facades\Blade;
use Illuminate\Support\ServiceProvider;

class OpsWizardBuildersServiceProvider extends ServiceProvider
{
    protected string $moduleName = 'OpsWizardBuilders';
    protected string $moduleNameLower = 'opswizardbuilders';

    public function boot(): void
    {
        $this->registerConfig();
        $this->registerViews();
        $this->registerTranslations();
        $this->loadMigrationsFrom(module_path($this->moduleName, 'Database/Migrations'));
    }

    public function register(): void
    {
        $this->app->register(RouteServiceProvider::class);
    }

    protected function registerConfig(): void
    {
        $this->publishes([
            module_path($this->moduleName, 'Config/config.php') => config_path($this->moduleNameLower . '.php'),
            module_path($this->moduleName, 'Config/ops-automations.php') => config_path('ops-automations.php'),
        ], 'config');

        $this->mergeConfigFrom(module_path($this->moduleName, 'Config/config.php'), $this->moduleNameLower);

        if (file_exists(module_path($this->moduleName, 'Config/ops-automations.php'))) {
            $this->mergeConfigFrom(module_path($this->moduleName, 'Config/ops-automations.php'), 'ops-automations');
        }
    }

    public function registerTranslations(): void
    {
        $langPath = resource_path('lang/modules/' . $this->moduleNameLower);

        if (is_dir($langPath)) {
            $this->loadTranslationsFrom($langPath, $this->moduleNameLower);
            $this->loadJsonTranslationsFrom($langPath);
        } else {
            $this->loadTranslationsFrom(module_path($this->moduleName, 'Resources/lang'), $this->moduleNameLower);
            $this->loadJsonTranslationsFrom(module_path($this->moduleName, 'Resources/lang'));
        }
    }

    public function registerViews(): void
    {
        $moduleViewBase = module_path($this->moduleName, 'Resources/views');

        $this->loadViewsFrom([$moduleViewBase . '/ops-scouts'], 'ops-scouts');
        $this->loadViewsFrom([$moduleViewBase . '/ops-automations'], 'ops-automations');
        $this->loadViewsFrom([$moduleViewBase], $this->moduleNameLower);

        $componentNamespace = str_replace('/', '\\', config('modules.namespace') . '\\' . $this->moduleName . '\\' . config('modules.paths.generator.component-class.path'));
        Blade::componentNamespace($componentNamespace, $this->moduleNameLower);
    }
}
