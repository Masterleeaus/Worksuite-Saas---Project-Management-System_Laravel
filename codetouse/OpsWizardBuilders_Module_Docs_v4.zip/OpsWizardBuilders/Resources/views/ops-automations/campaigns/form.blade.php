@extends('layouts.app')

@section('content')
<div class="w-full">
    <div class="mb-4">
        <h1 class="text-xl font-semibold">Automation Campaign</h1>
        <p class="text-sm text-gray-500">Recovery view added because the original automation zip referenced <code>ops-automations::campaigns.form</code> but did not include it.</p>
    </div>

    @includeIf('ops-automations::campaigns.list')
</div>
@endsection
