<div class="grid grid-cols-1 gap-6 lg:grid-cols-2">
    @include('ops-scouts::analytics.charts.published-posts', ['chartData' => $publishedChartData, 'months' => $publishedMonths])
    @include('ops-scouts::analytics.charts.engagement-rate', ['chartData' => $engagementChartData, 'months' => $engagementMonths])
    @include('ops-scouts::analytics.charts.impressions', ['chartData' => $impressionsChartData, 'months' => $impressionsMonths])
    @include('ops-scouts::analytics.charts.audience-growth', ['chartData' => $audienceChartData, 'months' => $audienceMonths])
</div>
