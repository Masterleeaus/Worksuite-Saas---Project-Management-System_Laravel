@php
    $theme = get_theme();
@endphp

@extends('panel.layout.app', ['disable_tblr' => true])
@section('title', __('Social Media Accounts'))
@section('titlebar_subtitle', __('You can connect and manage multiple social media accounts from here.'))
@section('titlebar_actions')
    @include('ops-scouts::components.titlebar-actions')
@endsection

@section('content')
    <div @class(['px-5', 'py-5' => $theme !== 'ops-scouts-dashboard'])>
        @include('ops-scouts::accounts.banner')
        @include('ops-scouts::accounts.platform-cards', ['platforms' => $platforms])
        @include('ops-scouts::accounts.platforms-table', ['platforms' => $userPlatforms])
    </div>
@endsection
