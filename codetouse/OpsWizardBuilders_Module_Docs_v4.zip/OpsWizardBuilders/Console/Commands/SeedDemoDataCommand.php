<?php

namespace Modules\OpsWizardBuilders\Console\Commands;

use App\Extensions\Scout\System\Database\Seeders\ScoutDemoSeeder;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Console\Command\Command as CommandAlias;

class SeedDemoDataCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'ops-scouts:seed-demo-data';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Seed demo agents and posts for Social Media Agent extension';

    /**
     * Execute the console command.
     */
    public function handle(): int
    {
        $this->info('Starting Social Media Agent demo data seeding...');
        $this->newLine();

        Log::info('ops-scouts:seed-demo-data started');

        $seeder = new ScoutDemoSeeder;
        $seeder->setCommand($this);
        $seeder->run();

        $this->newLine();
        $this->info('✅ Demo data seeding completed!');
        Log::info('ops-scouts:seed-demo-data finished');

        return CommandAlias::SUCCESS;
    }
}
