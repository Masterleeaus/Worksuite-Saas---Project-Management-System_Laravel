<?php

namespace Modules\OpsWizardBuilders\Console\Commands\Concerns;

use Modules\OpsWizardBuilders\Jobs\Automation\UserPostJob;
use Exception;

trait HasDynamicHandle
{
    public function dynamicHandle(string $repeat_period): void
    {
        $posts = $this->query($repeat_period)->get();

        if ($posts->count()) {
            $this->query($repeat_period)->update(['command_running' => true, 'last_run_date'   => now()->toDateString()]);
        }

        foreach ($posts as $post) {
            try {
                dispatch(new UserPostJob($post));
            } catch (Exception $e) {
                continue;
            }
            $post->update(['command_running' => true]);
        }
    }
}
