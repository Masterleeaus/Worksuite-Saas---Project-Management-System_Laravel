<?php

use Illuminate\Support\Facades\Route;
use Modules\OpsWizardBuilders\Http\Controllers\Agent\ScoutAnalysisController;
use Modules\OpsWizardBuilders\Http\Controllers\Agent\ScoutChatController;
use Modules\OpsWizardBuilders\Http\Controllers\Agent\ScoutChatSettingsController;
use Modules\OpsWizardBuilders\Http\Controllers\Agent\ScoutController;
use Modules\OpsWizardBuilders\Http\Controllers\Agent\ScoutOutputController;
use Modules\OpsWizardBuilders\Http\Controllers\Automation\Api\InstagramController;
use Modules\OpsWizardBuilders\Http\Controllers\Automation\AutomationController;
use Modules\OpsWizardBuilders\Http\Controllers\Automation\AutomationPlatformController;
use Modules\OpsWizardBuilders\Http\Controllers\Automation\AutomationSettingController;
use Modules\OpsWizardBuilders\Http\Controllers\Automation\AutomationStepController;
use Modules\OpsWizardBuilders\Http\Controllers\Automation\GenerateContentController;
use Modules\OpsWizardBuilders\Http\Controllers\Automation\UploadController;
use Modules\OpsWizardBuilders\Http\Middleware\Automation\AutomationCacheMiddleware;

Route::group(['middleware' => ['web', 'auth']], function () {
    Route::name('dashboard.user.ops.scouts.')
        ->prefix('dashboard/user/ops/scouts')
        ->group(function () {
            Route::get('chat/{id?}', [ScoutChatController::class, 'index'])->name('chat.index');
            Route::get('', [ScoutController::class, 'index'])->name('index');
            Route::get('post-items', [ScoutController::class, 'postItems'])->name('post-items');
            Route::get('create', [ScoutController::class, 'create'])->name('create');
            Route::get('agents', [ScoutController::class, 'agents'])->name('agents');
            Route::get('calendar', [ScoutController::class, 'calendar'])->name('calendar');
            Route::get('posts', [ScoutController::class, 'posts'])->name('posts');
            Route::get('analytics', [ScoutController::class, 'analytics'])->name('analytics');
            Route::get('accounts', [ScoutController::class, 'accounts'])->name('accounts');
            Route::post('', [ScoutController::class, 'store'])->name('store');
            Route::get('{agent}/edit', [ScoutController::class, 'edit'])->name('edit');
            Route::put('{agent}', [ScoutController::class, 'update'])->name('update');
            Route::delete('{agent}', [ScoutController::class, 'destroy'])->name('destroy');
            Route::post('scrape-website', [ScoutController::class, 'scrapeWebsite'])->name('scrape-website');
            Route::post('generate-targets', [ScoutController::class, 'generateTargets'])->name('generate-targets');
            Route::post('preview-post', [ScoutController::class, 'previewPost'])->name('preview-post');
            Route::post('{agent}/generate-posts', [ScoutController::class, 'generatePosts'])->name('generate-posts');
            Route::post('posts/{post}/approve', [ScoutController::class, 'approvePost'])->name('posts.approve');
            Route::post('{agent}/approve-bulk', [ScoutController::class, 'approveBulk'])->name('approve-bulk');
            Route::delete('posts/{post}/reject', [ScoutController::class, 'rejectPost'])->name('posts.reject');
            Route::post('posts/{post}/duplicate', [ScoutController::class, 'duplicatePost'])->name('posts.duplicate');
            Route::get('analyses', [ScoutAnalysisController::class, 'index'])->name('analyses.index');
            Route::get('analyses/{analysis}', [ScoutAnalysisController::class, 'show'])->name('analyses.show');
            Route::post('analyses/{analysis}/read', [ScoutAnalysisController::class, 'markAsRead'])->name('analyses.mark-read');
            Route::delete('analyses/{analysis}', [ScoutAnalysisController::class, 'destroy'])->name('analyses.destroy');
            Route::delete('analyses', [ScoutAnalysisController::class, 'clearAll'])->name('analyses.clear-all');
            Route::get('api/pending-count', [ScoutController::class, 'getPendingCount'])->name('api.pending-count');
            Route::get('api/posts', [ScoutController::class, 'getPosts'])->name('api.posts');
            Route::post('api/posts', [ScoutController::class, 'storePost'])->name('api.posts.store');
            Route::post('api/upload-image', [ScoutController::class, 'uploadImage'])->name('api.upload-image');
            Route::put('api/posts/{post}', [ScoutController::class, 'updatePost'])->name('api.posts.update');
            Route::post('api/posts/generate-content', [ScoutController::class, 'generatePostContent'])->name('api.posts.generate-content');
            Route::post('api/posts/{post}/regenerate', [ScoutOutputController::class, 'regenerateContent'])->name('api.posts.regenerate');
            Route::post('api/posts/generate-image', [ScoutController::class, 'generatePostImage'])->name('api.posts.generate-image');
            Route::get('api/generation-status', [ScoutController::class, 'getGenerationStatus'])->name('api.generation-status');
        });

    Route::prefix('oauth')->controller(InstagramController::class)->group(function () {
        Route::get('redirect/instagram', 'redirect')->name('oauth.connect.instagram');
        Route::get('callback/instagram', 'callback')->name('oauth.callback.instagram');
    });

    Route::prefix('dashboard')->name('dashboard.')->group(function () {
        Route::prefix('user')->name('user.')->group(function () {
            Route::controller(AutomationPlatformController::class)->prefix('automation/platform')->name('automation.platform.')->group(function () {
                Route::get('', 'index')->name('list');
                Route::post('update/{platform}', 'update')->name('update');
                Route::get('disconnect/{automationPlatform}', 'disconnect')->name('disconnect');
            });

            Route::controller(AutomationController::class)->prefix('automation')->name('automation.')->group(function () {
                Route::post('upload', UploadController::class)->name('upload');
                Route::post('genPost', [GenerateContentController::class, 'generateContent'])->name('generate-content');
                Route::controller(AutomationStepController::class)->middleware([AutomationCacheMiddleware::class])->group(function () {
                    Route::get('', 'stepFirst')->name('index');
                    Route::any('step/two', 'stepSecond')->name('step.second');
                    Route::any('step/third', 'stepThird')->name('step.third');
                    Route::any('step/fourth', 'stepFourth')->name('step.fourth');
                    Route::any('step/fifth', 'stepFifth')->name('step.fifth');
                    Route::any('step/last', 'stepLast')->name('step.last');
                    Route::any('step/store', 'storeScheduledPost')->name('step.store');
                });
                Route::post('', 'nextStep')->name('postindex');
                Route::get('scheduled-posts', 'scheduledPosts')->name('list');
                Route::get('scheduled-posts/delete/{id}', 'scheduledPostsDelete')->name('delete');
                Route::post('scheduled-posts/edit/{id}', 'scheduledPostsEdit')->name('edit');
                Route::prefix('company')->name('company.')->group(function () {
                    Route::get('get-products/{company_id}', 'getProducts')->name('getProducts');
                });
                Route::prefix('campaign')->name('campaign.')->group(function () {
                    Route::get('', 'campaignList')->name('list');
                    Route::get('add-or-update/{id?}', 'campaignAddOrUpdate')->name('addOrUpdate');
                    Route::get('delete/{id?}', 'campaignDelete')->name('delete');
                    Route::post('save', 'campaignAddOrUpdateSave')->name('campaignAddOrUpdateSave');
                    Route::get('get-target/{campaign_id}', 'getCampaignTarget')->name('getCampaignTarget');
                    Route::post('genTopics', 'generateCampaignTopics')->name('genTopics');
                });
                Route::post('update', 'updateAutomation')->name('update');
                Route::post('getCompany', 'getCompany')->name('getCompany');
                Route::post('getSelectedProducts', 'getSelectedProducts')->name('getSelectedProducts');
            });
        });
    });
});

Route::group(['middleware' => ['web', 'auth', 'admin'], 'prefix' => 'dashboard/admin/social-media/agent/chat'], function () {
    Route::get('settings', [ScoutChatSettingsController::class, 'index'])->name('dashboard.admin.social-media.agent.chat.settings');
    Route::post('settings', [ScoutChatSettingsController::class, 'update'])->name('dashboard.admin.social-media.agent.chat.settings.update');
});

Route::group(['middleware' => ['web', 'auth', 'admin'], 'prefix' => 'dashboard/admin/automation'], function () {
    Route::get('settings', [AutomationSettingController::class, 'index'])->name('dashboard.admin.automation.settings');
    Route::post('settings/update', [AutomationSettingController::class, 'update'])->name('dashboard.admin.automation.settings.update');
});

Route::post('ops-scouts/fal-webhook', [ScoutController::class, 'falWebhook'])
    ->middleware(['api'])
    ->name('dashboard.user.ops.scouts.fal-webhook');
