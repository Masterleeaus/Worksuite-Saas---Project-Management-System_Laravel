<?php

namespace Modules\OpsWizardBuilders\Enums\Automation;

enum Platform: string
{
    case x = 'x';
    case linkedin = 'linkedin';
    case instagram = 'instagram';
}
