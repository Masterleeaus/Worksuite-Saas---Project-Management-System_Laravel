<?php

return [
    'name' => 'OpsWizardBuilders',
    'view_namespaces' => [
        'ops-scouts' => module_path('OpsWizardBuilders', 'Resources/views/ops-scouts'),
        'ops-automations' => module_path('OpsWizardBuilders', 'Resources/views/ops-automations'),
    ],
];
