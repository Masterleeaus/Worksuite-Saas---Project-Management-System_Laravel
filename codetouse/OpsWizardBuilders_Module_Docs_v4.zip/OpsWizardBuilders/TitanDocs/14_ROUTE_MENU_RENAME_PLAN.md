# Route and menu rename plan

## Current state
The module shell has already been pushed toward ops language, but internal legacy naming still survives in parts of the codebase.

## Target naming
### Wizard products
- NexusAI
- NexusEngine
- NexusCore

### Human-readable labels
- AI Builder
- System Programmer
- Ops Interface

## Recommended menu layer
- Command Centre
- NexusAI
- NexusEngine
- NexusCore
- Approvals
- Domain Switcher

## Recommended route families
These are suggested target route families for a later rename pass.

### NexusAI
- `dashboard.user.nexus.ai.index`
- `dashboard.user.nexus.ai.create`
- `dashboard.user.nexus.ai.edit`
- `dashboard.user.nexus.ai.deploy`

### NexusEngine
- `dashboard.user.nexus.engine.index`
- `dashboard.user.nexus.engine.create`
- `dashboard.user.nexus.engine.edit`
- `dashboard.user.nexus.engine.deploy`

### NexusCore
- `dashboard.user.nexus.core.index`
- `dashboard.user.nexus.core.create`
- `dashboard.user.nexus.core.edit`
- `dashboard.user.nexus.core.deploy`

## Blade namespace direction
Suggested end-state namespace family:
- `nexus-ai::*`
- `nexus-engine::*`
- `nexus-core::*`

## Important rename rule
Do not perform a blind find-and-replace across deep schema and legacy services unless the backing logic is also being revalidated.
Use staged rename passes:
1. menu labels
2. route names
3. view folder names
4. provider/module namespaces
5. deep models/services/migrations where safe

## UI wording rule
Any remaining "social" references must be treated as technical debt and tracked until removed or mapped into ops language.
