# Object Forge Spec

## Purpose
Object Forge is the proposed third wizard. It is the structured creation layer for the business objects that Scouts and Automations need to produce.

## Objects it should support
- jobs
- quotes
- invoices
- bookings
- checklists
- service issues
- service agreements

## Why it exists
Without a shared object creation layer, Scouts and Automations can detect and route work but still need ad hoc logic to create actual business records. Object Forge centralizes that responsibility.

## Proposed 8-step wizard

### Step 1 — Object Type
Choose the target record type.

### Step 2 — Context Source
Manual, automation, scout output, imported lead, or existing customer/site context.

### Step 3 — Entity Binding
Attach customer, site, staff, package, service type, or related entities.

### Step 4 — Field Mapping
Define required fields, defaults, transforms, and custom field logic.

### Step 5 — AI Assistance
Let Titan Zero suggest pricing, wording, duration, assignment, or schedule.

### Step 6 — Approval Policy
Draft only, approval required, or auto-create inside rule limits.

### Step 7 — Output Actions
Save, notify, assign, queue follow-up, or hand off to another workflow.

### Step 8 — Lifecycle Hooks
Quote to job, job to invoice, issue to task, booking to job, and similar progressions.

## Architectural note
Object Forge should be a configuration-driven profile on the same shared wizard engine, not a separate bespoke subsystem.
