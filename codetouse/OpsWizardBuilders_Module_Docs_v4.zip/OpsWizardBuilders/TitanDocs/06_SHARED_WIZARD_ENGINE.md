# Shared Wizard Engine

## Principle
All three manufacturing pages should use one shared wizard engine rather than three unrelated implementations.

## Wizard profiles
- Scout Builder profile
- Automation Factory profile
- Object Forge profile

## Core engine responsibilities
- step registration
- per-step validation
- draft save and resume
- review and activation states
- permissions and approvals
- domain bindings
- AI assist side panel
- status and deployment state
- templates and presets
- versioning support

## Benefits
- consistent user experience
- easier maintenance
- reusable validation and persistence rules
- faster addition of future wizard types
- shared styling and global frame alignment

## Conversion intent
The two extracted MagicAI wizards should be treated as source material to be normalized into this shared engine rather than preserved as permanently separate wizard systems.
