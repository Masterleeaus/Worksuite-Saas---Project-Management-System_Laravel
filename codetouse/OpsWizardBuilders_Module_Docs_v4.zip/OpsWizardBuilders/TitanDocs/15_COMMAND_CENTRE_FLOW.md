# Command Centre flow

## Goal
The user should feel like they are managing a digital workforce from one machine, not jumping between unrelated apps.

## Fixed frame
The persistent interface should keep:
- top menu
- left sidebar
- right Titan Zero chat rail
- same card grid rhythm

## Fluid center
Only the operational substance changes by page or domain.

### In manufacturing pages
The center becomes the build surface for:
- NexusAI
- NexusEngine
- NexusCore

### In domain pages
The center becomes the operational dashboard for:
- Money
- Jobs
- Admin
- Growth
- Social or future channels where relevant

## User journey
1. User notices an operational need.
2. Titan Zero explains which builder is relevant.
3. User opens NexusAI, NexusEngine, or NexusCore.
4. User builds or edits the needed worker, logic chain, or object rule.
5. Sentinel governance and approvals apply.
6. The result appears back inside the domain dashboard.

## Core conceptual chain
- NexusAI builds the worker.
- NexusEngine builds the behavior.
- NexusCore builds the operational thing.
- Sentinels govern.
- Titan Zero explains, recommends, and refines.

## Product outcome
This makes the SaaS feel like an operating system with manufacturing surfaces rather than a menu of disconnected tools.
