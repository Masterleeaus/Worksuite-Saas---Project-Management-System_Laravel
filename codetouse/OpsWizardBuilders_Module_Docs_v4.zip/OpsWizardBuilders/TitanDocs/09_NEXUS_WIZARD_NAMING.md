# Nexus wizard naming stack

This module now has a clean three-wizard product model.

## Wizard set
- **NexusAI** — AI Builder
- **NexusEngine** — System Programmer
- **NexusCore** — Ops Interface

## Meaning of each

### NexusAI
Builds the specialist intelligence layer.

It is the place where a user creates and tunes:
- scouts
- agents
- role-specific AI workers
- tool belts
- knowledge access
- guardrails
- patrol schedules
- deployment state

### NexusEngine
Builds the process and automation layer.

It is the place where a user programs:
- triggers
- filters
- mappings
- reasoning steps
- actions
- notifications
- activation rules
- automation deployment

### NexusCore
Builds the operational object and interface layer.

It is the place where a user defines and creates:
- jobs
- quotes
- invoices
- bookings
- issues
- checklists
- service agreements
- conversion hooks between records

## Why this stack works
- NexusAI builds the worker.
- NexusEngine builds the behavior.
- NexusCore builds the operational thing.

The user is not just clicking through CRUD pages.
The user is manufacturing a digital workforce and the records it acts on.

## Product subtitle stack
Recommended display format:

- **NexusAI**  
  *AI Builder*
- **NexusEngine**  
  *System Programmer*
- **NexusCore**  
  *Ops Interface*

## Governance rule
These names must stay strict everywhere:
- docs
- menus
- routes
- blade titles
- controller labels
- helper text
- onboarding copy

Do not let NexusAI drift into automation language.
Do not let NexusEngine drift into object-creation language.
Do not let NexusCore drift into platform-kernel language unless intentionally expanded.
