# Automation Factory Spec

## Purpose
Automation Factory is the manufacturing page for logical pathways. It builds the if-then chains that connect Scouts, data, Titan Zero reasoning, record creation, and notifications.

## Wizard profile
This page uses a 6-step workflow wizard.

### Step 1 — Trigger
Examples:
- a Scout finds a lead
- a website form is submitted
- a job changes status
- an invoice becomes overdue

### Step 2 — Filter
Examples:
- verified phone only
- residential category only
- amount above threshold
- service region matches rule

### Step 3 — Data Mapping
Examples:
- push lead data to CRM
- bind customer and site fields
- extract service frequency
- transform source fields into record fields

### Step 4 — Logic
Examples:
- Titan Zero drafts an intro
- Titan Zero suggests a best-fit worker
- Titan Zero recommends pricing or timing
- Titan Zero scores risk or urgency

### Step 5 — Action
Examples:
- create draft quote
- schedule a follow-up task
- assign a worker
- create a record through Object Forge
- send a notification

### Step 6 — Deploy
Examples:
- active or inactive
- draft or production
- approval required or direct
- visible logging and run history

## Page modules
- automation list
- draft, active, error tabs
- recent runs
- failure queue
- wizard canvas
- deployment panel
- Titan Zero help rail

## Architectural note
Automation Factory should not be a one-off social flow. It should become a domain-agnostic workflow profile built on the shared wizard engine.
