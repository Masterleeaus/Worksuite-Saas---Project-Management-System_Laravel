# NexusEngine spec

## Purpose
NexusEngine is the **System Programmer**.
It builds the logical pathways that connect signals, decisions, and actions.

## Core role
NexusEngine is the process construction surface.
It defines what happens, when it happens, and under what conditions.

## Main object it builds
- Automation
- Workflow
- Trigger chain

## Primary responsibilities
- trigger definition
- filtering and conditions
- data mapping
- AI reasoning step configuration
- action chain setup
- notification logic
- deployment state
- workflow testing and iteration

## Expected 6-step wizard
1. Trigger
2. Filter / Condition
3. Data Mapping
4. Logic / Reasoning
5. Action
6. Deploy

## Recommended page zones
### Left panel
- automation list
- draft / active / paused / failed tabs
- health counters

### Center panel
- workflow builder
- step editor
- run preview

### Right panel
- Titan Zero guidance
- dependency warnings
- linked scouts
- last run notes

## Relationship to NexusAI
NexusEngine can call Scouts, but it does not define their identity.
Scouts are built in NexusAI.

## Relationship to NexusCore
NexusEngine can call object creation and lifecycle hooks, but it does not define the object schema.
Objects are built in NexusCore.

## Example automations
- New lead arrives -> qualify -> create quote draft -> notify admin
- Visit completed -> generate invoice draft -> queue approval
- Compliance issue detected -> create service issue -> assign manager follow-up
- Overdue invoice detected -> draft outreach -> log task -> notify owner

## Hard architecture rule
NexusEngine owns flow logic, not worker identity and not object model definition.
