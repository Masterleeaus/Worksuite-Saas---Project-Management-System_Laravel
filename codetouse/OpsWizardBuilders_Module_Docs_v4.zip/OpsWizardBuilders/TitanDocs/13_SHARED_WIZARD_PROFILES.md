# Shared wizard profiles

## Principle
NexusAI, NexusEngine, and NexusCore must sit on top of **one shared wizard framework**.

Do not build three unrelated wizards.
Build one engine with three profiles.

## Shared engine responsibilities
- step rendering
- step validation
- draft save / resume
- review screen
- deployment state
- permissions
- contextual help
- Titan Zero guidance panel
- template loading
- versioning
- activation / deactivation

## Profile split
### NexusAI profile
Builds workers.

### NexusEngine profile
Builds logic chains.

### NexusCore profile
Builds operational records.

## Why this matters
A shared framework gives:
- consistent UI rhythm
- less maintenance
- reusable validation
- easier onboarding
- cleaner docs
- cleaner future expansion

## Consistency rules
All three profiles should preserve:
- same stepper structure
- same draft patterns
- same review/activate experience
- same right-rail AI help behavior
- same error presentation
- same status language where possible

## Allowed profile-specific differences
- step labels
- field groups
- object previews
- deployment controls
- policy warnings
- linked entities

## Future extensibility
This shared engine should allow future wizard profiles without rebuilding the system:
- onboarding builder
- compliance builder
- campaign builder
- portal builder
- integration builder
