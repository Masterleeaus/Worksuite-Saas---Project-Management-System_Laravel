# OpsWizardBuilders Docs Index

This first documentation pack captures the product logic and architecture direction defined in the latest design exchanges.

## Included docs
- `01_OPERATING_MODEL.md` — Titan Zero, Sentinels, Scouts, Automations, and Object Forge roles.
- `02_GLOBAL_INTERFACE.md` — fixed-frame dashboard and fluid-center domain model.
- `03_AUTOMATION_FACTORY_SPEC.md` — 6-step automation/workflow wizard.
- `04_SENTINELS_AND_SCOUTS_SPEC.md` — 9-step scout builder and chain-of-command model.
- `05_OBJECT_FORGE_SPEC.md` — proposed third wizard for jobs, quotes, invoices, and related records.
- `06_SHARED_WIZARD_ENGINE.md` — shared framework rules for all wizard profiles.
- `07_IMPLEMENTATION_SEQUENCE.md` — phased build order and integration notes.

## Intent
These docs are the first design set only. They define the architecture and product logic to guide future conversion of the extracted MagicAI wizard flows into Titan Zero manufacturing pages.
