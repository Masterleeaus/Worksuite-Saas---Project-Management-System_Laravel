# Ops Rename Pass

This pass removes the main **social-media** surface from the module shell and reorients the artifact toward operations.

## Renamed surfaces
- Module: `SocialWizardBuilders` -> `OpsWizardBuilders`
- Scout views: `Resources/views/social-media-agent` -> `Resources/views/ops-scouts`
- Automation views: `Resources/views/ai-social-media` -> `Resources/views/ops-automations`
- Agent-side classes/files renamed toward `Scout*`
- Route names/prefixes moved toward `dashboard.user.ops.*`
- Config file renamed to `Config/ops-automations.php`

## Preserved legacy internals
Some deep implementation internals are still legacy-first to preserve source behavior in this pass:
- migration filenames and table names
- some automation service filenames tied to original provider/platform logic
- platform-specific classes such as Instagram/LinkedIn/Twitter integrations

A later pass can rename schema/entities more aggressively once the ops domain model is finalized.
