# NexusCore spec

## Purpose
NexusCore is the **Ops Interface**.
It builds the operational objects the system uses and the rules around their creation.

## Core role
NexusCore is the business object and operational surface layer.
It defines the structured records that Scouts and Automations act on.

## Main objects it builds
- jobs
- quotes
- invoices
- bookings
- service issues
- checklists
- service agreements

## Primary responsibilities
- object type definition
- source binding
- entity binding
- field mapping
- AI assistance rules
- approval policy
- output actions
- lifecycle hooks

## Recommended 8-step wizard
1. Object Type
2. Context Source
3. Entity Binding
4. Field Mapping
5. AI Assist Rules
6. Approval Logic
7. Output Actions
8. Lifecycle Hooks

## Why NexusCore matters
Without NexusCore, Scouts and Automations can detect, reason, and route, but they still need a structured operational layer to create the real business record.

## Recommended output examples
- quote draft from a website lead
- job from an approved quote
- invoice draft from a completed visit
- issue record from a compliance failure
- checklist from a service template

## Lifecycle examples
- quote -> job
- job -> invoice
- issue -> task
- booking -> job
- checklist template -> assigned checklist

## Hard architecture rule
NexusCore should not be hardcoded only to jobs, quotes, and invoices.
It must be built as a reusable object framework so new operational records can be added without building a separate wizard each time.
