# OpsWizardBuilders module scan

- Deep-scanned `modules.zip` and used real module layout patterns from `Aitools`, `Biolinks`, `BookingModule`, and `TitanAgents`.
- Wrapped both extracted MagicAI wizard families into a Nwidart-style module named `OpsWizardBuilders`.
- Preserved original route names and original Blade namespaces (`ops-scouts::` and `ops-automations::`) where practical.
- Pulled in extra linked files from the original zips: commands, command concerns, service contracts, platform service adapters, helpers, middleware, and migrations.
- Added a recovery view for `ops-automations::campaigns.form`, which was referenced in the original zip but missing from source.

## Known external host dependencies still expected
- `App\Extensions\SocialMedia\System\*`
- `App\Domains\Entity\*`
- `App\Models\*`
- `App\Helpers\Classes\*`
- `App\Http\Middleware\CheckTemplateTypeAndPlan`

This pass keeps those references visible instead of stubbing them so the real integration surface stays explicit.
