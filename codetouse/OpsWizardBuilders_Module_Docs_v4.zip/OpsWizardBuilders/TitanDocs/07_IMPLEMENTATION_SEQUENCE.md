# Implementation Sequence

## Goal
Convert the extracted wizard module into the first Titan Zero manufacturing layer.

## Recommended order

### Phase 1 — Preserve source flows
- keep both extracted wizard families intact
- document their current structure
- identify which parts are reusable and which are domain-specific

### Phase 2 — Create shared wizard framework
- centralize step flow handling
- unify review, validation, draft save, and deployment logic
- define configuration profiles for each wizard type

### Phase 3 — Rename and reposition
- convert the source wizard identities into:
  - Scout Builder
  - Automation Factory
- move toward Titan Zero product language

### Phase 4 — Add Object Forge
- build the third wizard profile on the shared engine
- support jobs, quotes, invoices, bookings, checklists, and service issues

### Phase 5 — Attach to fixed-frame UI
- wire into the global dashboard shell
- keep right-rail Titan Zero chat persistent
- keep card slots structurally consistent across domains

### Phase 6 — Connect governance and approvals
- link Scouts to Sentinels
- link Automations to deployment controls
- link Object Forge outputs to approval rules and lifecycle hooks

## Immediate artifact purpose
This docs set is the first architectural pack. It captures the intended operating model so future implementation passes can convert the current wizard module from inherited MagicAI flows into Titan Zero manufacturing pages.
