# Operating Model

## Core idea
Titan Zero is not just a chatbot. It is the reasoning layer of a business operating system that lets users manufacture automated behavior.

## Roles

### Titan Zero
- reasoning
- synthesis
- recommendation
- explanation
- contextual guidance inside every wizard

Titan Zero is the mind of the system. It helps the user configure the system, explains steps, and refines outputs, but it should remain distinct from the workers and governance layers.

### Sentinels
- domain governance
- oversight
- approval and policy boundaries
- reporting back to Titan Zero

Sentinels do not perform the work directly. They supervise and govern domain activity such as Jobs, Money, Admin, Growth, and Social.

### Scouts
- single-purpose specialists
- specific tool belts
- targeted patrols or checks
- optional user-facing communication

Scouts are the hands of the system. They detect, analyze, qualify, generate, and propose actions within their defined remit.

### Automations
- logical pathways
- cross-domain orchestration
- trigger-driven or event-driven flows
- deployment state and status tracking

Automations connect Scouts, records, notifications, and Titan Zero logic into repeatable workflows.

### Object Forge
- shared structured creation layer
- produces jobs, quotes, invoices, bookings, checklists, issues, and related records
- callable by Scouts and Automations

Object Forge is the missing third pillar. It creates the actual business objects the rest of the system acts on.

## Operating chain

A clean operating flow looks like this:

1. Scout detects or proposes
2. Automation evaluates and routes
3. Object Forge creates or drafts the business record
4. Sentinel governs, approves, or blocks
5. Titan Zero explains, advises, and helps refine

## Product effect
This architecture lets the user feel like they are hiring digital workers, assigning them to generals, linking them to workflows, and manufacturing automated intelligence without writing code.
