# NexusAI spec

## Purpose
NexusAI is the **AI Builder**.
It builds Scouts and links them to Sentinels and operational duties.

## Core role
NexusAI is the intelligence construction surface.
It defines who the worker is, what it can access, how it behaves, and how it reports.

## Main object it builds
- Scout

## Parent governance object
- Sentinel

## Primary responsibilities
- scout identity
- domain assignment
- tool selection
- knowledge source binding
- persona and tone
- guardrails and constraint level
- patrol schedule
- success metric definition
- deployment activation

## Expected 9-step wizard
1. Name & Icon
2. Sentinel Assignment
3. Primary Skill / Tool Belt
4. Data Access / Knowledge Sources
5. Persona
6. Guardrails
7. Schedule
8. Communication Style
9. Final Sync / Deployment

## Recommended page zones
### Left panel
- scout roster
- draft / active / paused / error tabs
- domain filters

### Center panel
- multi-step builder
- selected scout profile
- health summary

### Right panel
- Titan Zero explanation
- linked automations
- policy warnings
- recommendations

## Sentinel relationship
A Scout should never be treated as the governance layer.
The Sentinel governs.
The Scout performs its specialist role and reports upward.

## Example Scout types
- Overdue Invoice Scout
- Lead Qualification Scout
- Schedule Gap Scout
- Compliance Watch Scout
- Route Efficiency Scout
- Quote Follow-up Scout

## Hard architecture rule
NexusAI builds specialist workers.
It does not directly own business record creation or end-to-end workflow programming.
Those belong to NexusCore and NexusEngine.
