# Global Unified Interface

## Principle
Do not change the global layout when changing domains. The frame stays fixed and only the center substance changes.

## Persistent frame

### Top bar
- domain switcher
- manufacturing pages
- system status
- lenses or modes
- alerts and approvals

### Left sidebar
- dashboard
- records
- settings
- domain navigation

### Right panel
- Titan Zero chat
- contextual explanation
- warnings
- examples
- guidance while using any wizard

## Fluid center
The center panel changes by domain while keeping the same overall slot structure.

### Money domain examples
- cash flow
- overdue invoices
- expenses
- revenue risk

### Jobs domain examples
- active schedule
- worker maps
- compliance tasks
- missed visits

### Growth domain examples
- lead intake
- scout findings
- outreach queue
- conversion status

## Why this matters
A fixed frame creates muscle memory and removes context fatigue. The user learns one machine rather than several disconnected apps.

## Product rule
The shell stays stable. The data, cards, widgets, and meaning in the center swap by domain.
