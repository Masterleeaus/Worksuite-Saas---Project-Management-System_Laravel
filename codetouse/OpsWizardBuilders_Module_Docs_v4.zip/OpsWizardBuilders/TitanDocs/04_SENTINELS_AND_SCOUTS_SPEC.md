# Sentinels and Scouts Spec

## Purpose
Sentinels and Scouts is the management and manufacturing page for digital workers and their command hierarchy.

## Model

### Sentinel
A Sentinel is a domain general.

Examples:
- Money Sentinel
- Jobs Sentinel
- Admin Sentinel
- Growth Sentinel

Its role is governance, oversight, risk control, and policy alignment.

### Scout
A Scout is a specialist worker.

Examples:
- Overdue Invoice Chaser
- Prospect Scout
- Schedule Scout
- Compliance Scout

Its role is focused execution using a defined tool belt, knowledge scope, and operating policy.

## Wizard profile
This page uses a 9-step Scout configuration wizard.

### Step 1 — Name and Icon
Give the Scout a recognizable identity.

### Step 2 — Sentinel Assignment
Assign it to a governing domain or general.

### Step 3 — Primary Skill
Select the Scout's main tool or operational specialty.

### Step 4 — Data Access
Choose which modules, folders, records, or sources it can inspect.

### Step 5 — Persona
Set communication tone and behavioral style.

### Step 6 — Guardrails
Define what it cannot do and whether it is zero-hands, approval-only, or bounded.

### Step 7 — Schedule
Configure patrol frequency such as hourly, daily, weekly, or event-driven.

### Step 8 — Communication
Decide whether it logs quietly, reports to the user, or escalates through Command Centre.

### Step 9 — Final Sync
Review, validate, activate, and link the Scout into the wider system.

## Page modules
- sentinel overview cards
- scout roster
- scout health board
- wizard canvas
- patrol history
- linked automations
- Titan Zero guidance panel

## Product effect
This makes the AI feel like a managed workforce. Users can retrain or refine a Scout instead of feeling stuck with a vague black-box assistant.
