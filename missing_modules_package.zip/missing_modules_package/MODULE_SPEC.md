# Module Specification — TitanDispatch / CustomerPortal / TitanAnalytics
**Generated:** 2026-04-24

---

## TitanDispatch

### Existing: SynapseDispatch Module

**Models**
| Model | Table | Key Fields |
|---|---|---|
| DispatchJob | dispatch_jobs | team_id, location_id, worker_id, requested_start_datetime, requested_duration_minutes, flex_form_data (JSON skills_required), status |
| DispatchWorker | dispatch_workers | team_id, location_id, skills (JSON), business_hour (JSON), is_active |
| DispatchTeam | dispatch_teams | name, company_id |
| DispatchLocation | dispatch_locations | geo_latitude, geo_longitude |
| DispatchEvent | dispatch_events | job_id, worker_id, event_type, occurred_at |

**Services**

`HeuristicPlannerService::plan(DispatchJob): ?DispatchWorker`
- Returns best available worker using 100-point scoring:
  - 0–50 pts: skill match (required vs worker.skills intersection)
  - 0–50 pts: proximity (haversine distance, max score at 0km, zero at ≥100km)
- Filters by business hours (configurable per worker, per day)
- Filters by availability (no clash with existing assignments in window)

`HeuristicPlannerService::suggest(DispatchJob, limit=5): Collection`
- Returns top N workers with score + distance_km for UI display

`JobAssignmentService::assign(DispatchJob, DispatchWorker): void`
- Sets job.worker_id, status = assigned
- Fires JobAssigned event → NotifyWorkerOnAssignment listener → JobAssignedNotification (mail/push)

`WorkerAvailabilityService::isAvailable(DispatchWorker, Carbon $start, float $durationMinutes): bool`
- Checks no overlapping DispatchJob in the same time window

**Controllers (all in SynapseDispatch)**
| Controller | Routes |
|---|---|
| DispatchJobController | CRUD /dispatch/jobs |
| DispatchWorkerController | CRUD /dispatch/workers |
| DispatchTeamController | CRUD /dispatch/teams |
| DispatchLocationController | CRUD /dispatch/locations |
| PlannerController | GET /dispatch/planner — suggest workers for a job |
| MyJobsController | GET /dispatch/my-jobs — worker's own job list |

**Migrations** (all created)
- dispatch_locations, dispatch_teams, dispatch_workers, dispatch_jobs, dispatch_events

---

### Gaps: What Needs Building

#### RouteOptimizationService (scaffold provided)
Optimises the visit sequence for a worker's daily job list.

**Algorithm:** Nearest-neighbour TSP (O(n²), good for ≤20 stops)  
**Distance source:** Haversine (free, no API) → upgrade to OSRM or Google Maps Routes API  
**Method:** `optimise(DispatchWorker, Collection<DispatchJob>, string $date): Collection`

**Implementation path:**
1. Build `GreedyTspSolver` using `nearestNeighbour()` already in scaffold
2. Create `distanceMatrix()` using haversine from `HeuristicPlannerService`
3. Add time-window constraints (job.window_start / job.window_end)
4. Create `RouteOptimizationController@optimise` → return ordered job IDs
5. Render ordered list on dispatch board

#### RealTimeGpsController (scaffold provided)
Receives GPS pings from TitanGo and broadcasts to dispatch board.

**Required migration:**
```sql
CREATE TABLE worker_location_pings (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  worker_id INT UNSIGNED NOT NULL,
  lat DECIMAL(10,7) NOT NULL,
  lon DECIMAL(10,7) NOT NULL,
  accuracy_m FLOAT NULL,
  recorded_at TIMESTAMP NOT NULL,
  INDEX (worker_id, recorded_at)
);
```
**Broadcast:** `WorkerMoved` event → `dispatch.board.{companyId}` channel → Leaflet pin update

#### AutoSchedulerService (scaffold provided)
Nightly batch scheduling: assigns unassigned jobs to best workers.

**Artisan command:** `php artisan dispatch:auto-schedule {date} {--dry-run}`  
**Schedule:** `$schedule->command('dispatch:auto-schedule', [now()->addDay()->toDateString()])->dailyAt('22:00');`

#### Dispatch Board Map (scaffold provided)
Leaflet.js map overlay showing live worker positions + job site pins.

**JS events to subscribe (Pusher/Echo):**
- `WorkerMoved` → update worker pin
- `JobAssigned` → draw polyline from worker to job
- `JobStatusChanged` → update job pin colour

---

## Customer Portal

### Existing: FSMPortal Module (primary implementation)

**PortalJobController** — fully implemented:
| Method | Route | What it does |
|---|---|---|
| `index` | GET /portal/jobs | Paginated job list with status/date filters |
| `show` | GET /portal/jobs/{id} | Full job detail with stage timeline |
| `requestReclean` | POST /portal/jobs/{id}/reclean | Creates FSMPortalRecleanRequest + FSMActivity |
| `downloadPdf` | GET /portal/jobs/{id}/pdf | Streams PDF job completion report |
| `statusPoll` | GET /portal/jobs/{id}/status | JSON endpoint for live ETA polling |

**Middleware:** `EnsureClientCanViewOrder` — verifies `FSMOrder.location.partner_id = auth()->id()`

**Model:** `FSMPortalRecleanRequest` — tracks re-clean requests with status (pending/resolved)

**Views:**
- `portal/jobs/index.blade.php` — filterable job list
- `portal/jobs/show.blade.php` — detail with stage progress timeline, evidence photos, reclean form
- `portal/pdf/job_report.blade.php` — DomPDF-rendered completion certificate

---

### Gaps: What Needs Building

#### PortalPaymentController (scaffold provided)
**Effort: 3-5 days** — ZeroPay is fully built, this is just wiring.

```php
// Core implementation (3 lines):
$session = app(ZeroPaySessionService::class)->createSession([
    'invoice_id' => $invoiceId,
]);
return redirect($session->payment_link);
```

Routes to add:
```php
Route::get('/portal/invoices', [PortalPaymentController::class, 'index']);
Route::post('/portal/invoices/{id}/pay', [PortalPaymentController::class, 'pay']);
Route::get('/portal/invoices/{id}/receipt', [PortalPaymentController::class, 'receipt']);
```

#### PortalReviewController (scaffold provided)
**Effort: 3-5 days** — ClientPulse module already stores ratings.

```php
// Core implementation:
ClientPulse::createRating($jobId, $userId, $data['rating'], $data['comment']);
```

#### Unified Portal Dashboard (scaffold provided)
**Effort: 1-2 weeks**

`PortalDashboardViewModel` needs to aggregate:
- `$nextJob` — nearest upcoming FSMOrder (with live status polling via `statusPoll()`)
- `$invoices` — unpaid invoices from `invoices` table
- `$recentJobs` — last 5 completed orders
- `$notifications` — unread company messages

---

## TitanAnalytics

### Existing: Report Module

**Controllers (all implemented with views):**
| Controller | Report | Key metrics |
|---|---|---|
| `BookingReportController` | Booking performance | Count, completion rate, cancellations by period |
| `CleanerPerformanceReportController` | Cleaner scorecard | Jobs completed, avg rating, on-time rate |
| `RevenueByZoneReportController` | Zone revenue | Revenue per zone, top zones |
| `RouteEfficiencyReportController` | Route efficiency | km driven, jobs per route, idle time |
| `ChemicalUsageReportController` | Chemical usage | Litres used by type, cost |

**Scheduled Commands (all implemented):**
- `WeeklyBookingSummaryCommand` — fires every Monday
- `MonthlyFinancialSummaryCommand` — fires on 1st of month
- `DailyCleanerScheduleCommand` — fires daily at configurable time

**Accountings: JobProfitabilityService**
- `getProfitabilityReport(array $filters): array` — revenue vs cost per job
- Used by `JobProfitabilityController` with `job_profitability.blade.php` view

---

### Gaps: What Needs Building

#### AnalyticsDashboardController (scaffold provided)
**Effort: 1-2 weeks**

Unified endpoint: `GET /analytics/summary?start=X&end=Y`

Queries to implement (data already in DB):
```sql
-- Revenue for period
SELECT SUM(amount) FROM payments WHERE company_id=? AND paid_at BETWEEN ? AND ?;

-- Bookings by status
SELECT COUNT(*), status FROM bookings WHERE company_id=? AND created_at BETWEEN ? AND ?
GROUP BY status;

-- Daily revenue trend
SELECT DATE(paid_at) as d, SUM(amount) as rev FROM payments
WHERE company_id=? AND paid_at BETWEEN ? AND ?
GROUP BY DATE(paid_at) ORDER BY d;
```

Period comparison:
```php
$prevStart = Carbon::parse($start)->sub($period);
$prevEnd   = Carbon::parse($end)->sub($period);
$delta = (($current - $previous) / max($previous, 1)) * 100;
```

#### analytics_dashboard.blade.php (scaffold provided)
Chart.js + flatpickr — structure already written, needs data endpoint wired in.

#### ScheduledReportCommand (scaffold provided)
**Effort: 1 week**

Weekly/monthly executive email with dashboard snapshot.
Reuse `WeeklyBookingSummaryCommand` pattern — it already works.

---

## Quick Win Priority Order

1. **Portal Payments** (3-5 days) — `PortalPaymentController::pay()` is 3 lines once ZeroPay is confirmed working
2. **Analytics KPI cards** (3-5 days) — 4 SQL queries + blade template, no new infrastructure
3. **Portal unified dashboard** (1-2 weeks) — assemble existing ViewModels
4. **Analytics charts** (1 week) — Chart.js on top of existing query results
5. **Dispatch GPS** (1-2 weeks) — new table + Pusher broadcast + Leaflet map
6. **Route optimisation** (2-3 weeks) — greedy solver first, then upgrade
7. **Auto-scheduler** (1-2 weeks) — batch cron using existing HeuristicPlannerService

---

*Spec generated by Claude Code — April 24, 2026*
