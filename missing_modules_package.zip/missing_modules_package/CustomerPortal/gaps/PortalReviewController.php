<?php

namespace Modules\CustomerPortal\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;

/**
 * PortalReviewController
 *
 * SCAFFOLD — NOT YET IMPLEMENTED
 *
 * Let clients submit star ratings and text reviews after a job completes.
 * Hooks into ClientPulse module (already exists) for rating storage.
 *
 * GAPS TO BUILD:
 *   1. Show rating prompt when job stage = completion stage
 *   2. Star-rating form (1–5) + optional text comment
 *   3. Submit to ClientPulse (RatingController or direct model create)
 *   4. Prevent duplicate reviews per job
 *   5. Optional: NPS survey (0–10 scale) for company-wide score
 *   6. Thank-you confirmation page
 *   7. Admin notification on new review (email/Filament notification)
 *
 * Integration: ClientPulse module already stores ratings — just add portal UI.
 */
class PortalReviewController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * GET /portal/jobs/{jobId}/review
     * Show review form for a completed job.
     */
    public function create(int $jobId)
    {
        $userId = Auth::id();

        // TODO: load FSMOrder, verify client owns it, verify it's completed
        // TODO: check no existing review
        // return view('customerportal::review.create', compact('order'));

        throw new \RuntimeException('PortalReviewController::create() is not yet implemented.');
    }

    /**
     * POST /portal/jobs/{jobId}/review
     * Store the submitted review.
     */
    public function store(Request $request, int $jobId)
    {
        $data = $request->validate([
            'rating'  => 'required|integer|between:1,5',
            'comment' => 'nullable|string|max:2000',
        ]);

        $userId = Auth::id();

        // TODO: verify ownership + completion
        // TODO: ClientPulse::createRating($jobId, $userId, $data['rating'], $data['comment'])
        // TODO: fire ReviewSubmitted event → admin notification

        throw new \RuntimeException('PortalReviewController::store() is not yet implemented.');
    }
}
