<?php

namespace Modules\CustomerPortal\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;

/**
 * PortalPaymentController
 *
 * SCAFFOLD — NOT YET IMPLEMENTED
 *
 * Allows authenticated clients to view and pay their outstanding invoices
 * directly from the customer portal, without calling staff.
 *
 * GAPS TO BUILD:
 *   1. List unpaid invoices scoped to client
 *   2. Redirect to ZeroPay session (ZeroPaySessionService::createSession)
 *   3. OR redirect to Stripe Checkout (for non-ZeroPay companies)
 *   4. Webhook confirmation posts back to portal
 *   5. Show payment history / receipts with download links
 *   6. Installment / partial payment toggle (config flag)
 *
 * Integration: ZeroPay module is already built — just wire it here.
 * ZeroPaySessionService::createSession(['invoice_id' => $id, 'amount' => $due])
 */
class PortalPaymentController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * GET /portal/invoices
     * List unpaid (and recent paid) invoices for the logged-in client.
     */
    public function index()
    {
        $userId = Auth::id();

        // TODO: load invoices where client_id = userId
        // TODO: eager-load zeropay_sessions (check if active session exists)
        // TODO: show outstanding balance, due date, payment status

        throw new \RuntimeException('PortalPaymentController::index() is not yet implemented.');
    }

    /**
     * POST /portal/invoices/{id}/pay
     * Initiate payment for a specific invoice via ZeroPay.
     */
    public function pay(Request $request, int $invoiceId)
    {
        $userId = Auth::id();

        // TODO: verify invoice belongs to client
        // TODO: call ZeroPaySessionService::createSession(['invoice_id' => $invoiceId])
        // TODO: redirect to $session->payment_link

        throw new \RuntimeException('PortalPaymentController::pay() is not yet implemented.');
    }

    /**
     * GET /portal/invoices/{id}/receipt
     * Download receipt PDF for a paid invoice.
     */
    public function receipt(int $invoiceId)
    {
        // TODO: verify paid, generate download token via DownloadTokenService, redirect
        throw new \RuntimeException('PortalPaymentController::receipt() is not yet implemented.');
    }
}
