{{--
  portal_dashboard.blade.php
  SCAFFOLD — NOT YET IMPLEMENTED

  Unified customer portal home page. Aggregates:
    • Next upcoming job (with live status + ETA)
    • Outstanding invoices with Pay Now button
    • Recent completed jobs with Review / Download buttons
    • Notification feed (unread alerts)
    • Quick links: Book again, Contact us

  GAPS TO BUILD:
    1. Auth middleware: ensure only client role accesses
    2. PortalDashboardViewModel: aggregates jobs + invoices + notifications
    3. Live status polling (fetch /portal/jobs/{id}/status every 60s when job is in-progress)
    4. Toast notifications for new messages from company
    5. Mobile-responsive layout (Tailwind grid)
    6. "Book again" button → links to BookingModule public booking page
--}}

@extends('customerportal::layouts.app')

@section('title', 'My Portal')

@section('content')
<div class="portal-dashboard container py-8">

    {{-- UPCOMING JOB --}}
    <section class="mb-8">
        <h2 class="text-xl font-semibold mb-4">Next Job</h2>
        {{-- TODO: render PortalDashboardViewModel::$nextJob --}}
        <div class="bg-yellow-50 border border-yellow-200 rounded p-4 text-yellow-700">
            ⚠️ Scaffold: next job widget not yet implemented.
        </div>
    </section>

    {{-- INVOICES --}}
    <section class="mb-8">
        <h2 class="text-xl font-semibold mb-4">Outstanding Invoices</h2>
        {{-- TODO: loop $invoices, show Pay Now button → PortalPaymentController@pay --}}
        <div class="bg-yellow-50 border border-yellow-200 rounded p-4 text-yellow-700">
            ⚠️ Scaffold: invoice list not yet implemented.
        </div>
    </section>

    {{-- RECENT JOBS --}}
    <section class="mb-8">
        <h2 class="text-xl font-semibold mb-4">Recent Jobs</h2>
        {{-- TODO: loop $recentJobs from FSMPortal::PortalJobController --}}
        <div class="bg-yellow-50 border border-yellow-200 rounded p-4 text-yellow-700">
            ⚠️ Scaffold: recent jobs list not yet implemented.
        </div>
    </section>

</div>
@endsection
