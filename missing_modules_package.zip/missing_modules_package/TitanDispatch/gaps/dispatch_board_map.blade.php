{{--
  dispatch_board_map.blade.php
  SCAFFOLD — NOT YET IMPLEMENTED

  Live map overlay for the dispatch board showing:
    • Worker pins with colour-coded status (available / en-route / on-job)
    • Job site pins with status badge
    • Planned route polylines per worker
    • Click-to-assign drag interaction

  GAPS TO BUILD:
    1. Embed Leaflet.js or Google Maps JS SDK
    2. Subscribe to dispatch.board.{companyId} Pusher channel
    3. On WorkerMoved event → update worker pin position (animate)
    4. On JobAssigned event  → draw route polyline from worker to job
    5. Drag-and-drop job card onto worker pin to manually assign
    6. ETA label on each polyline
    7. Cluster pins when zoomed out
--}}

<div id="dispatch-map" style="height: 600px; width: 100%; border-radius: 8px;"
     data-company="{{ auth()->user()->company_id ?? '' }}">
    {{-- Map renders here via JS --}}
</div>

@push('scripts')
<script>
// TODO: initialise Leaflet / Google Maps
// TODO: connect to Echo channel 'dispatch.board.{{ auth()->user()->company_id }}'
// TODO: listen for 'WorkerMoved' and 'JobAssigned' events
// TODO: render worker + job pins from initial /api/titandispatch/workers/locations

console.warn('Dispatch map scaffold: JS not yet implemented.');
</script>
@endpush
