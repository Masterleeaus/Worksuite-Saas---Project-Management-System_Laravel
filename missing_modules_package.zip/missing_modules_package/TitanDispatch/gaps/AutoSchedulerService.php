<?php

namespace Modules\TitanDispatch\Services;

use Carbon\Carbon;
use Illuminate\Support\Collection;
use Modules\SynapseDispatch\Models\DispatchJob;
use Modules\SynapseDispatch\Services\HeuristicPlannerService;

/**
 * AutoSchedulerService
 *
 * SCAFFOLD — NOT YET IMPLEMENTED
 *
 * Drives the "auto-assign" nightly/weekly scheduling run.
 * For each unassigned job in a date window, finds the best worker
 * (via HeuristicPlannerService) and assigns them.
 *
 * GAPS TO BUILD:
 *   1. Batch job query (unassigned, within window, sorted by priority/SLA)
 *   2. SLA enforcement: high-priority jobs assigned first
 *   3. Capacity guard: don't exceed worker daily hour limit
 *   4. Conflict detection: don't double-book a worker
 *   5. Dry-run mode: return plan without persisting
 *   6. Artisan command: php artisan dispatch:auto-schedule {date}
 *   7. Email summary report after run
 */
class AutoSchedulerService
{
    public function __construct(
        protected HeuristicPlannerService $planner
    ) {}

    /**
     * Run auto-scheduling for a given date.
     *
     * @param  string  $date        Y-m-d
     * @param  int     $companyId
     * @param  bool    $dryRun      If true, return plan without saving
     * @return array{assigned: int, skipped: int, plan: array}
     */
    public function run(string $date, int $companyId, bool $dryRun = false): array
    {
        // TODO: load unassigned jobs for date + companyId
        // TODO: sort by priority DESC, then by SLA deadline ASC
        // TODO: for each job: planner->plan($job) → assign if worker found
        // TODO: track daily capacity per worker
        // TODO: persist assignments unless $dryRun
        // TODO: return summary

        throw new \RuntimeException('AutoSchedulerService::run() is not yet implemented. See scaffold comments.');
    }

    /**
     * Validate that assigning $job to $worker won't exceed daily hour cap
     * or clash with existing assignments.
     */
    protected function canAssign(/* DispatchWorker */ $worker, DispatchJob $job, string $date): bool
    {
        // TODO: implement capacity + conflict check
        return false;
    }
}
