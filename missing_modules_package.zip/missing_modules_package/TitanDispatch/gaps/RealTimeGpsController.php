<?php

namespace Modules\TitanDispatch\Http\Controllers\Api;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

/**
 * RealTimeGpsController
 *
 * SCAFFOLD — NOT YET IMPLEMENTED
 *
 * Receives GPS pings from the TitanGo mobile app (or any worker device)
 * and broadcasts location updates to the dispatch board via Pusher/Reverb.
 *
 * GAPS TO BUILD:
 *   1. GPS ping store (worker_locations table or Redis geo hash)
 *   2. Broadcast event (WorkerLocationUpdated → Echo channel)
 *   3. Geofencing: fire event when worker enters/exits job site radius
 *   4. ETA recalculation after each ping
 *   5. Trail/breadcrumb storage for audit replay
 *
 * Required migration:
 *   worker_location_pings (id, worker_id, lat, lon, accuracy_m, recorded_at)
 *
 * Required broadcast channel:
 *   dispatch.board.{companyId}  (WorkerMoved event)
 */
class RealTimeGpsController extends Controller
{
    /**
     * POST /api/titandispatch/gps
     * Accept GPS ping from TitanGo worker app.
     */
    public function ping(Request $request): JsonResponse
    {
        $data = $request->validate([
            'worker_id'  => 'required|integer',
            'lat'        => 'required|numeric|between:-90,90',
            'lon'        => 'required|numeric|between:-180,180',
            'accuracy_m' => 'nullable|numeric|min:0',
        ]);

        // TODO: store ping in worker_location_pings table
        // TODO: broadcast WorkerMoved event to dispatch.board.{companyId}
        // TODO: check geofence and fire JobSiteArrived if within 50m of job location

        throw new \RuntimeException('RealTimeGpsController::ping() is not yet implemented. See scaffold comments.');
    }

    /**
     * GET /api/titandispatch/workers/locations
     * Return current location of all active workers for the dispatch board map.
     */
    public function currentLocations(Request $request): JsonResponse
    {
        // TODO: query latest ping per worker_id from Redis or DB
        throw new \RuntimeException('RealTimeGpsController::currentLocations() is not yet implemented.');
    }
}
