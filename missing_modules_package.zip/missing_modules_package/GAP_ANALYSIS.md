# Missing Modules — Gap Analysis & Package Guide
**Generated:** 2026-04-24  
**Branches scanned:** `main`, `claude/zero-pay-module-spec-k2ebX`  
**Codebase:** Worksuite SaaS — Field Service Management (Laravel)

---

## Correction to Original Gap Report

The original gap report was written before a full branch scan. Actual completion
levels are higher than stated:

| Module           | Gap Report Said | Actual (post-scan) |
|------------------|-----------------|--------------------|
| TitanDispatch    | 0% (missing)    | ~45% done          |
| Customer Portal  | 80-90% done     | ~75% done          |
| TitanAnalytics   | 5% done         | ~30% done          |

---

## 1. TITANDISPATCH — Job Scheduling & Route Optimisation

### What Already Exists (in this repo)

| Location | What it does |
|---|---|
| `Modules/SynapseDispatch/` | Full dispatch module: Jobs, Workers, Teams, Locations, Events |
| `SynapseDispatch/Services/HeuristicPlannerService.php` | Skill + proximity scoring with haversine distance — **working** |
| `SynapseDispatch/Services/JobAssignmentService.php` | Assigns worker to job, fires JobAssigned event |
| `SynapseDispatch/Services/WorkerAvailabilityService.php` | Clash detection against existing assignments |
| `SynapseDispatch/Models/` | DispatchJob, DispatchWorker, DispatchTeam, DispatchLocation, DispatchEvent |
| `SynapseDispatch/Http/Controllers/` | CRUD for jobs, workers, teams, locations + Planner + MyJobs |
| `SynapseDispatch/Database/Migrations/` | 5 tables fully created |
| `BookingModule/Services/Dispatch/` | DispatchBoardQueryService, DispatchMoveService, DispatchScheduleUpdateService |
| `BookingModule/Http/Controllers/DispatchBoardController.php` | Booking-specific dispatch board |
| `Modules/FSMRoute/` | FSM route management (vehicle-based routes) |

### What's Still Missing

| Gap | File in `/gaps/` | Effort |
|---|---|---|
| **Route optimisation** (TSP/VRP for daily job sequences) | `RouteOptimizationService.php` | 2-3 weeks |
| **Real-time GPS tracking** (worker location pings → dispatch map) | `RealTimeGpsController.php` | 1-2 weeks |
| **Auto-scheduler** (nightly batch assign for tomorrow's jobs) | `AutoSchedulerService.php` | 1-2 weeks |
| **Live map view** (Leaflet/Google Maps with worker pins + job pins) | `dispatch_board_map.blade.php` | 1 week |
| **SLA enforcement** (priority queue, deadline warnings) | — | 1 week |
| **Artisan command** `dispatch:auto-schedule {date}` | — | 3 days |
| **Mobile worker app** GPS emit (TitanGo integration) | — | 2-3 weeks (TitanGo module scope) |

### Integration Notes
- `HeuristicPlannerService` is production-quality. Use it as-is.
- `WorkerAvailabilityService` must be extended to check `requested_duration_minutes`.
- Route optimisation: start with `GreedyDriver` (nearest-neighbour in scaffold),
  then swap to Google Maps Routes API for production.
- GPS: use `laravel-websockets` or Pusher → broadcast `WorkerMoved` event.

---

## 2. CUSTOMER PORTAL — Job Status, Payments, Reviews

### What Already Exists (in this repo)

| Location | What it does |
|---|---|
| `Modules/FSMPortal/` | **Most complete portal implementation** |
| `FSMPortal/Http/Controllers/PortalJobController.php` | Job list, job detail, re-clean request, PDF download, live status poll — **fully working** |
| `FSMPortal/Resources/views/portal/` | jobs/index, jobs/show, pdf/job_report — complete Blade views |
| `FSMPortal/Http/Middleware/EnsureClientCanViewOrder.php` | Auth guard for order ownership |
| `FSMPortal/Models/FSMPortalRecleanRequest.php` | Re-clean workflow model |
| `BookingModule/Http/Controllers/Web/Public/ClientPortalController.php` | Thin wrapper (booking-specific) |
| `BookingModule/Resources/views/public/client_portal.blade.php` | Basic booking list view |

### What's Still Missing

| Gap | File in `/gaps/` | Effort |
|---|---|---|
| **Self-service payments** (pay invoice from portal via ZeroPay) | `PortalPaymentController.php` | 3-5 days (ZeroPay already built — just wire it) |
| **Review/rating submission** (post-job star rating) | `PortalReviewController.php` | 3-5 days (ClientPulse module already stores ratings) |
| **Unified portal dashboard** (jobs + invoices + notifications in one view) | `portal_dashboard.blade.php` | 1-2 weeks |
| **Notification feed** (unread alerts from company) | — | 1 week |
| **Quote acceptance** (approve/reject quotes from portal) | — | 1 week |
| **Document centre** (download contracts, warranties, certificates) | — | 1 week |
| **Message thread** (chat with company without leaving portal) | — | 2 weeks (ChattingModule exists, integrate it) |

### Integration Notes
- **Payments**: `ZeroPaySessionService::createSession(['invoice_id' => $id])` is all you need.
  The ZeroPay module is 100% built. `PortalPaymentController.php` scaffold shows the exact call.
- **Reviews**: `ClientPulse` module already stores ratings. Just add a Blade form.
- **Dashboard**: Use `PortalJobController::statusPoll()` for live ETA updates (already implemented).
- **Auth**: `FSMPortal` uses `partner_id` on `FSMLocation`. Ensure booking module clients
  are also linked via the same or equivalent relationship.

---

## 3. TITANANALYTICS — Dashboards, Metrics, Reports

### What Already Exists (in this repo)

| Location | What it does |
|---|---|
| `Modules/Report/` | 5 report controllers with views + scheduled commands |
| `Report/Http/Controllers/BookingReportController.php` | Booking performance report |
| `Report/Http/Controllers/CleanerPerformanceReportController.php` | Cleaner scorecard |
| `Report/Http/Controllers/RevenueByZoneReportController.php` | Revenue by zone |
| `Report/Http/Controllers/RouteEfficiencyReportController.php` | Route efficiency |
| `Report/Http/Controllers/ChemicalUsageReportController.php` | Chemical usage |
| `Report/Console/WeeklyBookingSummaryCommand.php` | Weekly email digest — **exists** |
| `Report/Console/MonthlyFinancialSummaryCommand.php` | Monthly email digest — **exists** |
| `Modules/Accountings/Services/JobProfitabilityService.php` | Job cost vs revenue — **working** |
| `TitanCore/Http/Controllers/Api/MetricsController.php` | Prometheus-format AI usage metrics |
| `TitanCore/Config/metrics.php` | Metrics config |

### What's Still Missing

| Gap | File in `/gaps/` | Effort |
|---|---|---|
| **Executive KPI dashboard** (single-page unified view) | `AnalyticsDashboardController.php`, `analytics_dashboard.blade.php` | 1-2 weeks |
| **Period comparison** (this month vs last month / YoY) | — (add to controller) | 3-5 days |
| **CSV / PDF export** from dashboard | — (add to controller) | 3-5 days |
| **Scheduled email delivery** of dashboard snapshot | `ScheduledReportCommand.php` | 1 week |
| **Filament widgets** (Chart.js cards in admin panel) | — | 1 week |
| **Custom date range picker** with chart reload | — (in blade scaffold) | 2-3 days |
| **Real-time metric streaming** (WebSockets) | — | 2-3 weeks |
| **Custom report builder** (ad-hoc queries by non-devs) | — | 4-6 weeks |

### Integration Notes
- All data already exists. No new tables needed for MVP analytics.
- Extend `Report` module controllers — don't duplicate them.
- Use Chart.js (CDN, no npm required for MVP).
- `WeeklyBookingSummaryCommand` + `MonthlyFinancialSummaryCommand` already schedule
  email digests — review and extend rather than rebuild.
- `JobProfitabilityService` is the key for margin analytics — it's production-ready.

---

## Package Contents

```
missing_modules_package/
├── GAP_ANALYSIS.md              ← this file
├── MODULE_SPEC.md               ← full spec of all three modules
│
├── TitanDispatch/
│   ├── existing/                ← copied from repo (working code)
│   │   ├── SynapseDispatch/     ← full module
│   │   ├── BookingDispatch/     ← controllers, services, views
│   │   └── FSMRoute/            ← FSM route module
│   └── gaps/                   ← scaffold files (stubs to implement)
│       ├── RouteOptimizationService.php
│       ├── RealTimeGpsController.php
│       ├── AutoSchedulerService.php
│       └── dispatch_board_map.blade.php
│
├── CustomerPortal/
│   ├── existing/                ← copied from repo (working code)
│   │   ├── FSMPortal/           ← primary portal implementation
│   │   └── BookingPublic/       ← booking-specific portal bits
│   └── gaps/                   ← scaffold files
│       ├── PortalPaymentController.php
│       ├── PortalReviewController.php
│       └── portal_dashboard.blade.php
│
└── TitanAnalytics/
    ├── existing/                ← copied from repo (working code)
    │   ├── ReportModule/        ← 5 report controllers + scheduled commands
    │   ├── TitanCoreMetrics/    ← metrics config + Prometheus controller
    │   └── AccountingsProfitability/  ← job cost/margin analysis
    └── gaps/                   ← scaffold files
        ├── AnalyticsDashboardController.php
        ├── analytics_dashboard.blade.php
        └── ScheduledReportCommand.php
```

---

## Revised Timeline to Complete

| Module | Effort Remaining | Priority |
|---|---|---|
| TitanDispatch — Route Optimisation | 2-3 weeks | HIGH (blocks field ops) |
| TitanDispatch — Real-time GPS | 1-2 weeks | HIGH |
| TitanDispatch — Auto-scheduler | 1-2 weeks | MEDIUM |
| Customer Portal — Payment (ZeroPay wire-up) | 3-5 days | HIGH (ZeroPay already done) |
| Customer Portal — Review submission | 3-5 days | MEDIUM |
| Customer Portal — Unified dashboard | 1-2 weeks | MEDIUM |
| TitanAnalytics — KPI dashboard | 1-2 weeks | HIGH |
| TitanAnalytics — Export + scheduled emails | 1 week | MEDIUM |

**MVP total remaining: ~8-10 weeks** (some can parallelise)

---

*Package generated by Claude Code — April 24, 2026*
