{{--
  analytics_dashboard.blade.php
  SCAFFOLD — NOT YET IMPLEMENTED

  Executive KPI dashboard powered by Chart.js.
  All data exists in the DB — this view just needs to be wired up.

  GAPS TO BUILD:
    1. Date range picker (flatpickr) → triggers AJAX reload
    2. KPI cards: Revenue, Bookings, Avg Job Value, Top Zone, Top Cleaner
    3. Revenue trend line chart (daily/weekly)
    4. Bookings status donut (completed / cancelled / upcoming)
    5. Cleaner league table (sortable)
    6. Zone heat map (Leaflet choropleth)
    7. Export buttons (CSV / PDF)
    8. Period comparison toggle (vs last month / vs last year)

  Data source: GET /analytics/summary?start=X&end=Y
--}}

@extends('layouts.app')
@section('title', 'TitanAnalytics — Dashboard')

@push('styles')
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
@endpush

@section('content')
<div class="container py-8">

    {{-- Date range filter --}}
    <div class="flex gap-4 mb-6">
        <input type="text" id="dateRange" class="border rounded px-3 py-2" placeholder="Select date range">
        <button onclick="loadDashboard()" class="btn btn-primary">Apply</button>
        <a href="/analytics/export?format=csv" class="btn btn-outline">Export CSV</a>
        <a href="/analytics/export?format=pdf" class="btn btn-outline">Export PDF</a>
    </div>

    {{-- KPI Cards --}}
    <div class="grid grid-cols-4 gap-4 mb-8">
        <div class="bg-white shadow rounded p-4">
            <p class="text-sm text-gray-500">Revenue</p>
            <p class="text-2xl font-bold" id="kpi-revenue">—</p>
            <p class="text-xs text-green-600" id="kpi-revenue-delta">vs previous period</p>
        </div>
        <div class="bg-white shadow rounded p-4">
            <p class="text-sm text-gray-500">Bookings</p>
            <p class="text-2xl font-bold" id="kpi-bookings">—</p>
        </div>
        <div class="bg-white shadow rounded p-4">
            <p class="text-sm text-gray-500">Avg Job Value</p>
            <p class="text-2xl font-bold" id="kpi-avg-value">—</p>
        </div>
        <div class="bg-white shadow rounded p-4">
            <p class="text-sm text-gray-500">Top Zone</p>
            <p class="text-2xl font-bold" id="kpi-top-zone">—</p>
        </div>
    </div>

    {{-- Charts --}}
    <div class="grid grid-cols-2 gap-6 mb-8">
        <div class="bg-white shadow rounded p-4">
            <h3 class="font-semibold mb-4">Revenue Trend</h3>
            <canvas id="revenueChart" height="200"></canvas>
        </div>
        <div class="bg-white shadow rounded p-4">
            <h3 class="font-semibold mb-4">Bookings by Status</h3>
            <canvas id="bookingsDonut" height="200"></canvas>
        </div>
    </div>

    {{-- ⚠️ Scaffold warning --}}
    <div class="bg-yellow-50 border border-yellow-300 rounded p-4 text-yellow-800">
        ⚠️ <strong>Scaffold:</strong> This view is not yet wired to real data.
        Implement <code>AnalyticsDashboardController::summary()</code> and connect via the JS below.
    </div>

</div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script>
flatpickr('#dateRange', { mode: 'range', dateFormat: 'Y-m-d' });

let revenueChart, bookingsChart;

async function loadDashboard() {
    const range = document.getElementById('dateRange').value.split(' to ');
    const start = range[0] || '';
    const end   = range[1] || range[0] || '';

    // TODO: uncomment when endpoint is implemented
    // const res = await fetch(`/analytics/summary?start=${start}&end=${end}`);
    // const data = await res.json();

    // STUB — replace with real data
    const data = {
        revenue: { total: 0, vs_previous_pct: 0 },
        bookings: { total: 0, completed: 0, cancelled: 0 },
        avg_job_value: 0,
        top_zone: '—',
        chart: { labels: [], revenue: [], bookings: [] },
    };

    document.getElementById('kpi-revenue').textContent = '$' + data.revenue.total.toLocaleString();
    document.getElementById('kpi-revenue-delta').textContent = data.revenue.vs_previous_pct + '% vs previous';
    document.getElementById('kpi-bookings').textContent = data.bookings.total;
    document.getElementById('kpi-avg-value').textContent = '$' + data.avg_job_value;
    document.getElementById('kpi-top-zone').textContent = data.top_zone;

    // Revenue trend line
    if (revenueChart) revenueChart.destroy();
    revenueChart = new Chart(document.getElementById('revenueChart'), {
        type: 'line',
        data: { labels: data.chart.labels, datasets: [{ label: 'Revenue', data: data.chart.revenue, borderColor: '#3b82f6', fill: false }] },
    });

    // Bookings donut
    if (bookingsChart) bookingsChart.destroy();
    bookingsChart = new Chart(document.getElementById('bookingsDonut'), {
        type: 'doughnut',
        data: {
            labels: ['Completed', 'Cancelled', 'Upcoming'],
            datasets: [{ data: [data.bookings.completed, data.bookings.cancelled, data.bookings.total - data.bookings.completed - data.bookings.cancelled], backgroundColor: ['#22c55e','#ef4444','#f59e0b'] }],
        },
    });
}

loadDashboard();
</script>
@endpush
