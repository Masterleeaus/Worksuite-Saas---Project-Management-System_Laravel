<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // TODO: define tables for suppliers
    }

    public function down(): void
    {
        // TODO: drop tables for suppliers
    }
};
