<?php

return [
    'name' => 'Communication',
];
