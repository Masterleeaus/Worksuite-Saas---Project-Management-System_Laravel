<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (Schema::hasTable('ai_tools_usage_history')) {
        Schema::table('ai_tools_usage_history', function (Blueprint $table) {
            if (!Schema::hasColumn('ai_tools_usage_history', 'total_requests')) {
                $table->bigInteger('total_requests')->default(1)->after('total_tokens');
            }
        });
    }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (Schema::hasTable('ai_tools_usage_history')) {
        Schema::table('ai_tools_usage_history', function (Blueprint $table) {
            if (Schema::hasColumn('ai_tools_usage_history', 'total_requests')) {
                $table->dropColumn('total_requests');
            }
        });
    }
    }
};
