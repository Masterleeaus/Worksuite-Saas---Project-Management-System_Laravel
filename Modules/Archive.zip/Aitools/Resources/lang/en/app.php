<?php

return [
    'chatgptTokens' => 'AI tokens',
    'chatgptTokensHelp' => 'Optional token allowance for AI usage (legacy field).',
    'totalAssignedTokens' => 'Total assigned tokens',
    'remainingTokens' => 'Remaining tokens',
];
