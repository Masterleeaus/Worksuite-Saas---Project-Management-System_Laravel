<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Modules\BookingModule\Entities\BookingModuleSetting;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        \App\Models\Module::validateVersion(BookingModuleSetting::MODULE_NAME);

        if (! Schema::hasTable('booking_offline_payments')) {
            return;
        }
        if (!Schema::hasColumn('booking_offline_payments', 'method_name')) {
            Schema::table('booking_offline_payments', function (Blueprint $table) {
                $table->text('method_name')->nullable()->after('booking_id');
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('booking_offline_payments', function (Blueprint $table) {
            $table->dropColumn('method_name');
        });
    }
};
